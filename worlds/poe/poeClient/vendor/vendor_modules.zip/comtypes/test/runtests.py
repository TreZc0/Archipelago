import sys

import comtypes.test


def main():
    sys.exit(comtypes.test.run(sys.argv[1:]))


if __name__ == "__main__":
    main()
