from enum import IntFlag

import comtypes.gen._C866CA3A_32F7_11D2_9602_00C04F8EE628_0_5_4 as __wrapper_module__
from comtypes.gen._C866CA3A_32F7_11D2_9602_00C04F8EE628_0_5_4 import (
    DISPID_SRRPhraseInfo, eLEXTYPE_PRIVATE15,
    DISPID_SRGDictationUnload, SPEI_MIN_TTS, SVF_Stressed,
    SP_VISEME_18, DISPID_SVAlertBoundary, DISPID_SDKSetStringValue,
    DISPID_SRGCmdSetRuleState, ISpStream, DISPID_SWFESamplesPerSec,
    SPGS_EXCLUSIVE, SPSERIALIZEDPHRASE, DISPID_SAVolume, SWTAdded,
    DISPID_SRCCmdMaxAlternates, SpPhraseInfoBuilder,
    SPRECOGNIZERSTATUS, DISPID_SPPsCount, eLEXTYPE_PRIVATE2,
    SPEI_RECO_OTHER_CONTEXT, SASRun, SGRSTTEpsilon, SVP_9,
    DISPID_SADefaultFormat, ISpeechRecoResult2, DISPID_SVEBookmark,
    SpeechPropertyAdaptationOn, STCRemoteServer, SVSFIsFilename,
    SPRST_INACTIVE_WITH_PURGE, SPRS_ACTIVE, STCInprocHandler,
    SPEI_PROPERTY_STRING_CHANGE, DISPID_SLWsItem, SPPS_RESERVED3,
    ISpVoice, SPSHT_NotOverriden, SAFT12kHz8BitMono, SRSActive,
    SPBINARYGRAMMAR, SAFT48kHz8BitMono, SVSFParseMask, DISPID_SAFType,
    ISpPhoneConverter, DISPID_SRCEEndStream, SVEViseme,
    SpeechPropertyNormalConfidenceThreshold,
    ISpPhoneticAlphabetSelection, SRCS_Disabled, DISPID_SASState,
    SPWT_DISPLAY, SPLO_STATIC, SVP_19, DISPID_SVEStreamStart,
    SPEI_ACTIVE_CATEGORY_CHANGED, SPINTERFERENCE_TOOQUIET,
    SAFTADPCM_11kHzMono, SPEI_SR_BOOKMARK, SAFTCCITT_uLaw_44kHzStereo,
    DISPID_SLPsCount, DISPID_SRCEStartStream, ISpeechPhraseRules,
    SVPAlert, SPAR_High, SDKLLocalMachine, eLEXTYPE_RESERVED9,
    SPINTERFERENCE_LATENCY_WARNING, SREStreamStart, SPSHT_Unknown,
    SPVOICESTATUS, ISpRecognizer2, SVSFParseSapi, DISPID_SVGetVoices,
    SSTTDictation, SRARoot, SVESentenceBoundary, DISPID_SPPConfidence,
    DISPID_SLRemovePronunciationByPhoneIds, ISpeechVoiceStatus,
    DISPID_SVStatus, DISPID_SVSInputWordLength, UINT_PTR,
    SDKLCurrentConfig, DISPID_SRRSaveToMemory,
    DISPID_SRCreateRecoContext, DISPID_SLPPhoneIds, DISPID_SBSSeek,
    SAFT48kHz8BitStereo, DISPID_SCSBaseStream,
    DISPID_SRCEPropertyStringChange, DISPID_SPRuleParent,
    ISpGrammarBuilder, ISpeechPhoneConverter,
    SPINTERFERENCE_LATENCY_TRUNCATE_END, DISPID_SRCEPhraseStart,
    SVP_12, SECFIgnoreCase, SSFMCreateForWrite, SPGS_ENABLED,
    ISpeechPhraseAlternate, SPSEMANTICERRORINFO, SP_VISEME_16,
    SSSPTRelativeToEnd, DISPID_SWFEAvgBytesPerSec, DISPID_SRRAudio,
    SPRULE, Speech_Max_Pron_Length, DISPID_SPERequiredConfidence,
    DISPID_SRCEPropertyNumberChange, SSFMOpenReadWrite, SVP_17,
    DISPID_SGRId, __MIDL___MIDL_itf_sapi_0000_0020_0002,
    ISpeechLexiconPronunciation, SpeechRegistryUserRoot,
    SAFTNoAssignedFormat, DISPID_SRAudioInput, SREInterference,
    SpLexicon, SGDisplay, IEnumSpObjectTokens, helpstring,
    DISPID_SPISaveToMemory, SAFT32kHz16BitStereo, SPSMF_UPS,
    SPWT_LEXICAL_NO_SPECIAL_CHARS, SGPronounciation,
    DISPID_SRCRetainedAudioFormat, CoClass, SPPHRASEPROPERTY,
    SPEI_TTS_PRIVATE, SpeechCategoryVoices, DISPID_SPIStartTime,
    SPWORD, SpeechPropertyHighConfidenceThreshold,
    SpUnCompressedLexicon, SINoSignal, SAFT24kHz8BitStereo,
    SAFTCCITT_ALaw_44kHzStereo, SpeechDictationTopicSpelling,
    SPEI_PHRASE_START, SPDKL_DefaultLocation, ISpeechPhraseAlternates,
    SLTApp, SPBO_PAUSE, DISPID_SLGenerationId, SVP_10, typelib_path,
    DISPID_SVGetAudioOutputs, SECHighConfidence,
    DISPID_SPIRetainedSizeBytes, SPEI_PROPERTY_NUM_CHANGE,
    SP_VISEME_20, DISPID_SWFEChannels, DISPID_SPPs_NewEnum,
    ISpObjectWithToken, DISPID_SVIsUISupported, DISPID_SVSpeak,
    DISPID_SWFEExtraData, ISpeechRecognizer, SRSInactive,
    SAFT48kHz16BitMono, SECNormalConfidence, SPEI_START_SR_STREAM,
    SPINTERFERENCE_TOOFAST, DISPID_SPPsItem, SAFTCCITT_ALaw_11kHzMono,
    SpeechCategoryAudioIn, DISPID_SRCState, DISPID_SRCEInterference,
    DISPID_SRCERequestUI, SPEI_TTS_AUDIO_LEVEL, DISPID_SPAs_NewEnum,
    SPRECOCONTEXTSTATUS, DISPID_SVSyncronousSpeakTimeout,
    SpeechPropertyResponseSpeed, SGRSTTWord, DISPID_SGRClear,
    SRADefaultToActive, ISpNotifySource, STSF_FlagCreate, SITooQuiet,
    DISPID_SPAsCount, DISPID_SPEAudioSizeBytes, eLEXTYPE_PRIVATE5,
    SVSFPurgeBeforeSpeak, DISPID_SLAddPronunciationByPhoneIds,
    SPFM_NUM_MODES, eLEXTYPE_LETTERTOSOUND, SpeechAudioProperties,
    SpVoice, SP_VISEME_17, DISPID_SGRSTPropertyValue,
    SAFT44kHz8BitMono, STSF_AppData, SPEI_SOUND_END, DISPID_SRRTimes,
    DISPID_SRCCreateGrammar, SPXRO_Alternates_SML,
    _ISpeechVoiceEvents, SP_VISEME_6, eLEXTYPE_PRIVATE17,
    SPPS_Unknown, STCAll, SPFM_CREATE, SDTAll, ISpRecoGrammar,
    STCLocalServer, DISPID_SGRsFindRule, DISPID_SGRSTPropertyName,
    SPCT_COMMAND, SRAInterpreter, SRTExtendableParse,
    DISPID_SPEDisplayAttributes, SGDSInactive,
    SAFTCCITT_uLaw_8kHzMono, DISPID_SRSSupportedLanguages,
    DISPID_SPEsCount, SRSEIsSpeaking, SPWF_INPUT,
    SPEI_END_INPUT_STREAM, DISPID_SVSkip, SAFTNonStandardFormat,
    SpeechTokenKeyFiles, DISPID_SPAStartElementInResult,
    DISPID_SVWaitUntilDone, DISPID_SPIProperties,
    DISPID_SRRAlternates, DISPID_SRCERecognition, SVP_8,
    DISPID_SPRs_NewEnum, DISPID_SRCSetAdaptationData,
    ISpeechRecoResultTimes, DISPID_SRGDictationLoad,
    SPRECORESULTTIMES, Speech_StreamPos_RealTime, SLTUser,
    DISPID_SVPriority, SGRSTTRule, DISPID_SPRNumberOfElements,
    SPEI_TTS_BOOKMARK, DISPID_SPRFirstElement, eLEXTYPE_PRIVATE6,
    SECFDefault, DISPID_SVResume, SVPOver, SAFTCCITT_uLaw_44kHzMono,
    DISPID_SVAudioOutputStream, SpMMAudioEnum, SFTSREngine,
    SPRST_NUM_STATES, SPAO_NONE, SREFalseRecognition, SREAudioLevel,
    ISpeechObjectTokenCategory, SVSFParseSsml, ISpeechMemoryStream,
    DISPID_SPEAudioStreamOffset, DISPID_SPCLangId, SPAO_RETAIN_AUDIO,
    SpeechTokenIdUserLexicon, SGLexical, ISpeechRecognizerStatus,
    SPAS_CLOSED, DISPID_SLRemovePronunciation, DISPID_SVEStreamEnd,
    DISPID_SRCEBookmark, SP_VISEME_15, COMMETHOD,
    DISPID_SABIMinNotification, SLODynamic, SVP_2,
    SpeechGrammarTagDictation, SAFT22kHz8BitMono, ISpRecognizer,
    DISPID_SDKGetStringValue, SpeechCategoryAudioOut,
    DISPID_SOTGetAttribute, DISPID_SRSetPropertyNumber,
    DISPID_SGRsAdd, DISPIDSPTSI_SelectionLength, SP_VISEME_14,
    DISPID_SRGState, SpShortcut, SRERecognition, DISPID_SVSPhonemeId,
    SpObjectToken, SpInprocRecognizer, SITooLoud, wireHWND,
    SPAUDIOBUFFERINFO, DISPID_SRGSetWordSequenceData,
    ISpeechPhraseProperties, ISpeechGrammarRuleStateTransitions,
    DISPID_SGRSTsItem, DISPID_SLPsItem, DISPID_SLPType, SPWF_SRENGINE,
    SPAS_RUN, SPEI_RESERVED1, SAFTGSM610_22kHzMono, DISPID_SOTDataKey,
    DISPID_SPRuleEngineConfidence, ISpeechResourceLoader,
    SVSFUnusedFlags, DISPID_SRAllowAudioInputFormatChangesOnNextSet,
    SPEI_INTERFERENCE, VARIANT_BOOL, SGDSActiveWithAutoPause,
    DISPID_SPRulesCount, SpeechCategoryAppLexicons, SPVPRI_NORMAL,
    SPBO_AHEAD, STSF_LocalAppData, DISPID_SOTCategory,
    ISpeechWaveFormatEx, DISPID_SLWPronunciations, tagSTATSTG,
    DISPID_SRStatus, SpMemoryStream, SAFT11kHz8BitStereo,
    DISPID_SPEsItem, SpSharedRecognizer,
    SSSPTRelativeToCurrentPosition, SAFT11kHz16BitStereo,
    SpeechRegistryLocalMachineRoot, SPBO_NONE,
    SAFTCCITT_ALaw_8kHzMono, SREBookmark,
    DISPID_SRGCmdLoadFromProprietaryGrammar,
    DISPID_SVSInputSentencePosition, SPSFunction, SRTReSent,
    DISPID_SPRuleNumberOfElements, DISPID_SRIsUISupported,
    SPRS_ACTIVE_WITH_AUTO_PAUSE, SPEI_SR_RETAINEDAUDIO,
    DISPID_SRSetPropertyString, SpWaveFormatEx, SpInProcRecoContext,
    DISPID_SRCEHypothesis, SPSSuppressWord, DISPID_SRCVoice,
    SpMMAudioOut, SINoise, eLEXTYPE_PRIVATE19, SPCT_SUB_DICTATION,
    SPINTERFERENCE_NONE, eLEXTYPE_USER_SHORTCUT,
    DISPID_SRCRetainedAudio, DISPID_SDKGetBinaryValue, DISPID_SOTId,
    eLEXTYPE_VENDORLEXICON, SAFTADPCM_44kHzStereo,
    DISPID_SDKEnumValues, dispid, DISPID_SPPFirstElement, SVSFIsXML,
    DISPID_SVSLastResult, SAFT22kHz8BitStereo, SPXRO_SML,
    ISpeechVoice, SRTEmulated, DISPID_SGRSTsCount,
    _ISpeechRecoContextEvents, DISPID_SVEVoiceChange, SpAudioFormat,
    DISPID_SVAllowAudioOuputFormatChangesOnNextSet, DISPID_SOTsItem,
    ISpeechAudioStatus, SPWP_UNKNOWN_WORD_UNPRONOUNCEABLE, VARIANT,
    SDTAudio, DISPID_SRCVoicePurgeEvent, DISPID_SRRRecoContext,
    SPEI_ADAPTATION, SpeechGrammarTagUnlimitedDictation,
    SPEI_RESERVED2, SAFT11kHz8BitMono, DISPID_SRRAudioFormat,
    DISPID_SVEViseme, SVP_18, SAFT16kHz8BitStereo, DISPID_SGRsDynamic,
    SAFT12kHz16BitStereo, SPSHT_OTHER, ISpeechPhraseInfoBuilder,
    SVP_1, SREPhraseStart, SSSPTRelativeToStart, SAFT8kHz8BitMono,
    DISPID_SBSRead, ISpeechPhraseReplacement, DISPID_SOTCDefault,
    eLEXTYPE_PRIVATE4, SGDSActive, DISPID_SVEAudioLevel,
    DISPID_SGRsCount, ISpeechXMLRecoResult, tagSPPROPERTYINFO,
    IServiceProvider, eLEXTYPE_PRIVATE13, SINone, eLEXTYPE_PRIVATE7,
    DISPID_SAFGetWaveFormatEx, DISPID_SVEventInterests,
    SpCustomStream, SPVPRI_ALERT, SSTTTextBuffer, eLEXTYPE_RESERVED6,
    _FILETIME, SPINTERFERENCE_NOSIGNAL, ISpNotifySink,
    SAFT24kHz16BitStereo, DISPID_SRGCmdLoadFromResource,
    SPEI_SR_AUDIO_LEVEL, DISPIDSPTSI_ActiveOffset,
    DISPID_SLPs_NewEnum, DISPID_SVSInputWordPosition, SVP_6,
    SAFT44kHz16BitMono, SVSFPersistXML, SPAUDIOSTATUS,
    DISPID_SDKDeleteValue, DISPID_SASFreeBufferSpace, IStream,
    SVEWordBoundary, ISpeechAudio,
    DISPID_SRCAudioInInterferenceStatus, DISPID_SRRGetXMLResult,
    DISPID_SVSVisemeId, SPSMF_SRGS_SEMANTICINTERPRETATION_W3C,
    SPRST_ACTIVE_ALWAYS, SpeechCategoryPhoneConverters,
    DISPID_SRCRecognizer, SPEI_VISEME, SPINTERFERENCE_TOOLOUD,
    ISequentialStream, SP_VISEME_13, SpeechUserTraining,
    SAFT32kHz8BitStereo, SECFNoSpecialChars, SREPropertyStringChange,
    DISPID_SRState, eLEXTYPE_PRIVATE16, SVSFNLPSpeakPunc,
    SGRSTTTextBuffer, DISPID_SPAPhraseInfo, DISPID_SWFEBlockAlign,
    SREStreamEnd, DISPID_SRSAudioStatus,
    DISPID_SPANumberOfElementsInResult, SPEI_RESERVED5,
    SPSMF_SRGS_SEMANTICINTERPRETATION_MS, SpeechRecoProfileProperties,
    SP_VISEME_0, DISPID_SPERetainedStreamOffset,
    DISPID_SRCEEnginePrivate, SAFT12kHz16BitMono, ISpeechObjectToken,
    SPWORDLIST, DISPID_SOTDisplayUI, SPSHT_EMAIL, SPEI_MAX_TTS,
    SPAR_Low, SP_VISEME_21, DISPID_SLAddPronunciation,
    ISpeechCustomStream, SAFTADPCM_22kHzStereo, DISPID_SGRSTWeight,
    SRSActiveAlways, DISPID_SLWs_NewEnum, DISPID_SRGCommit,
    WAVEFORMATEX, DISPID_SGRSTNextState, SPPHRASE, SP_VISEME_3,
    ISpeechAudioBufferInfo, SPAS_STOP, HRESULT, DISPID_SABufferInfo,
    DISPID_SGRs_NewEnum, SVSFlagsAsync, DISPID_SRGCmdLoadFromObject,
    SPPS_Interjection, eLEXTYPE_PRIVATE14, SGLexicalNoSpecialChars,
    SASClosed, DISPID_SDKSetLongValue, SVF_Emphasis,
    DISPID_SPIEnginePrivateData, DISPID_SPIRule, SPEVENTSOURCEINFO,
    DISPID_SPPEngineConfidence, DISPID_SRRSetTextFeedback,
    DISPID_SDKCreateKey, DISPID_SRGReset, SGDSActiveUserDelimited,
    SVEBookmark, SDA_One_Trailing_Space, SPINTERFERENCE_NOISE,
    SPSHORTCUTPAIR, SDA_No_Trailing_Space, DISPID_SOTCSetId,
    DISPID_SMSADeviceId, SpeechTokenValueCLSID, SpObjectTokenCategory,
    DISPID_SVGetProfiles, SpeechCategoryRecoProfiles,
    ISpeechTextSelectionInformation, SVSFVoiceMask, ISpeechRecoResult,
    DISPID_SBSFormat, ISpRecognizer3, ISpeechLexiconWord,
    eWORDTYPE_ADDED, SPSUnknown, DISPID_SLWType, SPPS_Function,
    ISpeechPhraseElements, ISpRecoGrammar2, ISpeechDataKey,
    DISPID_SGRSTRule, SVP_13, SVP_7, SWPKnownWordPronounceable,
    SAFTADPCM_11kHzStereo, ISpRecoCategory, SPEI_RESERVED3,
    ISpeechBaseStream, DISPID_SBSWrite, SRESoundStart,
    eWORDTYPE_DELETED, DISPID_SLGetWords, SpPhoneticAlphabetConverter,
    DISPID_SPCIdToPhone, DISPID_SVRate, SDA_Consume_Leading_Spaces,
    SP_VISEME_7, SpeechTokenKeyUI, SPPS_RESERVED4,
    DISPID_SPEAudioSizeTime, SVSFParseAutodetect, ISpEventSink,
    SAFTGSM610_11kHzMono, DISPID_SRGCmdSetRuleIdState,
    DISPID_SRGetPropertyNumber, DISPID_SVSRunningState,
    DISPID_SPIElements, DISPID_SDKSetBinaryValue, ISpeechRecoGrammar,
    eLEXTYPE_RESERVED7, SVEAllEvents, ISpRecoContext,
    SRERecoOtherContext, DISPID_SGRInitialState, SAFTGSM610_8kHzMono,
    DISPID_SASNonBlockingIO, ISpAudio, SPDKL_CurrentUser,
    DISPID_SRRTOffsetFromStart, DISPID_SRCERecognitionForOtherContext,
    SVP_21, SDKLDefaultLocation, DISPID_SRCRequestedUIType,
    DISPID_SVVolume, SPPS_RESERVED1, SDTPronunciation, Library,
    SPCS_ENABLED, SDTRule, SAFT16kHz16BitMono,
    SAFTExtendedAudioFormat, DISPID_SOTCGetDataKey,
    tagSPTEXTSELECTIONINFO, DISPID_SRRGetXMLErrorInfo, SWTDeleted,
    DISPID_SRGId, DISPID_SOTCEnumerateTokens, DISPID_SPIEngineId,
    DISPID_SFSOpen, eLEXTYPE_PRIVATE18, DISPID_SLGetGenerationChange,
    SBONone, SPSHORTCUTPAIRLIST, SREAdaptation, SVP_14,
    SPRS_ACTIVE_USER_DELIMITED, IEnumString, DISPID_SMSAMMHandle,
    DISPID_SRCEventInterests, SVEVoiceChange, SPWT_PRONUNCIATION,
    SpeechMicTraining, DISPID_SASetState, SVSFNLPMask,
    SPWP_UNKNOWN_WORD_PRONOUNCEABLE, SpeechTokenKeyAttributes,
    DISPID_SPIAudioSizeTime, DISPID_SRCEAudioLevel,
    DISPID_SPERetainedSizeBytes, ISpResourceManager, SPRST_ACTIVE,
    ISpeechPhraseReplacements, Speech_StreamPos_Asap,
    DISPID_SABIBufferSize, SRTAutopause, SVSFIsNotXML, SRAImport,
    DISPID_SVVoice, __MIDL_IWinTypes_0009, IUnknown,
    DISPIDSPTSI_ActiveLength, SDTAlternates,
    SAFTCCITT_uLaw_22kHzStereo, DISPID_SGRSTPropertyId,
    DISPID_SGRAttributes, DISPID_SRRSpeakAudio, DISPID_SMSALineId,
    SPFM_OPEN_READONLY, SRCS_Enabled, ISpPhrase, SPPS_Verb,
    SPEI_REQUEST_UI, ULONG_PTR, SPPS_NotOverriden, DISPID_SLWsCount,
    DISPID_SGRSAddRuleTransition, SECFEmulateResult, SDTDisplayText,
    SDTLexicalForm, SpeechVoiceSkipTypeSentence,
    SWPUnknownWordUnpronounceable, DISPID_SRCEAdaptation,
    DISPID_SRSCurrentStreamNumber, SPAR_Medium, DISPID_SRRTTickCount,
    DISPID_SRCCreateResultFromMemory, SPVPRI_OVER,
    DISPID_SPIReplacements, DISPID_SPRsCount, SPEI_START_INPUT_STREAM,
    DISPID_SRGRecoContext, SAFT11kHz16BitMono, SAFT24kHz8BitMono,
    SREPropertyNumChange, SpNullPhoneConverter, SGSEnabled,
    SPEI_MIN_SR, DISPID_SRSCurrentStreamPosition,
    SPEI_RECO_STATE_CHANGE, SPINTERFERENCE_LATENCY_TRUNCATE_BEGIN,
    SVP_4, SPPS_RESERVED2, SRSEDone, SVP_20, DISPID_SWFEFormatTag,
    SVP_15, _check_version, SVP_5, DISPID_SPEPronunciation,
    SVEAudioLevel, DISPID_SRCESoundStart, SVSFDefault,
    DISPID_SRCPause, SPPROPERTYINFO, SITooSlow, SASStop,
    DISPIDSPTSI_SelectionOffset, IInternetSecurityManager,
    SPFM_CREATE_ALWAYS, SREPrivate, SAFTCCITT_ALaw_8kHzStereo,
    ISpStreamFormat, SAFT44kHz8BitStereo, _LARGE_INTEGER,
    DISPID_SRGetPropertyString, DISPID_SVSCurrentStreamNumber,
    DISPID_SOTCreateInstance, SpStreamFormatConverter,
    DISPID_SPRsItem, SECFIgnoreWidth, DISPID_SOTMatchesAttributes,
    DISPID_SVSLastStreamNumberQueued, SP_VISEME_11, SRAORetainAudio,
    DISPID_SRSClsidEngine, SPCS_DISABLED, DISPID_SPPChildren,
    eLEXTYPE_PRIVATE10, SPSModifier, DISPID_SGRSRule, SPEI_SR_PRIVATE,
    SGRSTTDictation, SPDKL_LocalMachine, DISPID_SPEDisplayText,
    DISPID_SRGDictationSetState, BSTR, DISPID_SPEAudioTimeOffset,
    SpPhoneConverter, eLEXTYPE_RESERVED8, GUID, ISpXMLRecoResult,
    DISPID_SVSpeakStream, SP_VISEME_10, SpeechVoiceCategoryTTSRate,
    SRTStandard, SAFTCCITT_ALaw_44kHzMono, SPFM_OPEN_READWRITE,
    DISPID_SPILanguageId, DISPID_SGRAddResource, SPGS_DISABLED,
    ISpObjectToken, DISPID_SGRSAddWordTransition, DISPID_SLWLangId,
    DISPID_SRRDiscardResultInfo, SPCT_SUB_COMMAND, SAFT8kHz8BitStereo,
    SECFIgnoreKanaType, SVP_11, SpCompressedLexicon,
    eLEXTYPE_PRIVATE11, SGSExclusive,
    SpeechPropertyLowConfidenceThreshold, eLEXTYPE_PRIVATE1,
    SAFTCCITT_uLaw_11kHzMono, SITooFast, SPEI_HYPOTHESIS,
    SAFTGSM610_44kHzMono, SAFTCCITT_ALaw_22kHzMono,
    SAFT32kHz16BitMono, SPEI_PHONEME, LONG_PTR, SPWT_LEXICAL,
    SPPS_LMA, SP_VISEME_8, DISPID_SPRText, eLEXTYPE_PRIVATE12,
    DISPID_SPRuleName, SRSInactiveWithPurge, ISpProperties,
    DISPID_SPELexicalForm, DISPID_SWFEBitsPerSample,
    SpSharedRecoContext, DISPID_SRCERecognizerStateChange,
    ISpeechLexiconPronunciations, ISpeechLexiconWords, SGSDisabled,
    eLEXTYPE_APP, DISPID_SOTRemoveStorageFileName, eLEXTYPE_PRIVATE3,
    SPEI_UNDEFINED, SpeechCategoryRecognizers,
    SpeechPropertyComplexResponseSpeed, SPCT_DICTATION, SPSLMA,
    SREAllEvents, DISPID_SASCurrentSeekPosition, DISPID_SPIGetText,
    DISPID_SMSSetData, SPWORDPRONUNCIATION, DISPID_SVDisplayUI,
    SP_VISEME_9, DISPID_SPIGrammarId, SPPHRASEREPLACEMENT,
    DISPID_SRAllowVoiceFormatMatchingOnNextSet, SREHypothesis,
    SAFTADPCM_22kHzMono, DISPID_SPRulesItem, SPTEXTSELECTIONINFO,
    SpeechGrammarTagWildcard, DISPID_SRGCmdLoadFromFile,
    SPEI_VOICE_CHANGE, SpTextSelectionInformation, SAFTText, SPEVENT,
    DISPID_SDKDeleteKey, DISPID_SABufferNotifySize, DISPID_SVEPhoneme,
    SpeechAudioFormatGUIDWave, DISPID_SRProfile, ISpeechPhraseInfo,
    DISPID_SPEActualConfidence, ISpeechRecoContext, WSTRING,
    SVEPhoneme, DISPID_SRCResume, eLEXTYPE_RESERVED10, DISPID_SPPId,
    SECLowConfidence, ISpeechGrammarRules, SpFileStream,
    ISpPhoneticAlphabetConverter, SVEEndInputStream, DISPID_SAFGuid,
    DISPID_SPIGetDisplayAttributes, eLEXTYPE_MORPHOLOGY,
    DISPID_SDKEnumKeys, DISPID_SLPPartOfSpeech, SPPS_Noncontent,
    ISpObjectTokenCategory, SpeechAllElements,
    ISpeechGrammarRuleState, DISPID_SRGetFormat,
    DISPID_SVEEnginePrivate, SPAS_PAUSE, SAFT22kHz16BitStereo, SVP_3,
    STCInprocServer, SBOPause, SPBO_TIME_UNITS, SAFT22kHz16BitMono,
    SPRS_INACTIVE, SASPause, DISPID_SGRSAddSpecialTransition,
    SAFTADPCM_8kHzStereo, DISPID_SPRuleId, SPSMF_SRGS_SAPIPROPERTIES,
    DISPID_SPRuleFirstElement, SPWORDPRONUNCIATIONLIST,
    SpeechPropertyResourceUsage, ISpeechPhraseElement, SRAONone,
    SPSNoun, SPSMF_SAPI_PROPERTIES, SSTTWildcard, SPPS_Modifier,
    __MIDL___MIDL_itf_sapi_0000_0020_0001, DISPID_SOTs_NewEnum,
    ISpeechObjectTokens, DISPID_SREmulateRecognition, DISPID_SLWWord,
    SRADynamic, SP_VISEME_4, SpStream, SVEPrivate,
    SPDKL_CurrentConfig, DISPID_SABIEventBias, DISPID_SOTsCount,
    DISPID_SVGetAudioInputs, DISPID_SRGSetTextSelection,
    SPSInterjection, ISpeechAudioFormat, SVP_16, DISPID_SAStatus,
    ISpDataKey, _RemotableHandle, DISPID_SPPName,
    DISPID_SOTGetDescription, DISPID_SPPBRestorePhraseFromMemory,
    DISPID_SPRDisplayAttributes, SAFT24kHz16BitMono, SVP_0, SPSVerb,
    DISPID_SGRSTType, Speech_Default_Weight, SP_VISEME_5,
    DISPID_SGRSTText, SpeechAddRemoveWord, DISPID_SFSClose,
    DISPID_SPPNumberOfElements, ISpStreamFormatConverter, SP_VISEME_1,
    ISpeechLexicon, SRATopLevel, DISPID_SDKOpenKey, SDKLCurrentUser,
    DISPID_SDKGetlongValue, DISPID_SAEventHandle, DISPID_SRCBookmark,
    DISPID_SGRsCommitAndSave, SpeechAudioFormatGUIDText,
    DISPID_SPEs_NewEnum, DISPID_SGRName, SDA_Two_Trailing_Spaces,
    DISPID_SOTGetStorageFileName, DISPID_SOTRemove, DISPID_SOTSetId,
    DISPID_SPEEngineConfidence, SAFTTrueSpeech_8kHz1BitMono,
    SpeechAudioVolume, SVPNormal, DISPMETHOD, SAFT16kHz16BitStereo,
    DISPID_SGRAddState, DISPID_SRAudioInputStream, SDTProperty,
    SAFT32kHz8BitMono, DISPID_SVSInputSentenceLength,
    DISPID_SRIsShared, DISPID_SLGetPronunciations, ISpeechFileStream,
    DISPID_SRRecognizer, SAFT12kHz8BitStereo, DISPID_SRCESoundEnd,
    SAFT48kHz16BitStereo, DISPID_SMSGetData,
    SWPUnknownWordPronounceable, ISpMMSysAudio, ISpPhraseAlt,
    DISPID_SRCEFalseRecognition, SPAR_Unknown, eLEXTYPE_RESERVED4,
    SPWP_KNOWN_WORD_PRONOUNCEABLE, SSFMOpenForRead, SPEI_RESERVED6,
    SAFTDefault, DISPID_SPRuleConfidence, DISPID_SVAudioOutput,
    DISPID_SRGRules, DISPID_SRGIsPronounceable,
    ISpeechGrammarRuleStateTransition, SPEI_SENTENCE_BOUNDARY,
    DISPID_SGRSTs_NewEnum, DISPID_SPAsItem, SPEI_MAX_SR, SVF_None,
    ISpeechPhraseRule, eLEXTYPE_PRIVATE9, SREStateChange,
    DISPID_SPRuleChildren, SPPS_SuppressWord, DISPID_SLPSymbolic,
    _lcid, SPINTERFERENCE_TOOSLOW, DISPID_SGRSTransitions,
    SAFT16kHz8BitMono, ISpRecoResult, ISpeechRecoResultDispatch,
    eLEXTYPE_USER, Speech_Max_Word_Length, SAFTADPCM_44kHzMono,
    SSFMCreate, DISPID_SVSpeakCompleteEvent, eLEXTYPE_PRIVATE20,
    SPEI_SOUND_START, SAFT8kHz16BitStereo, STSF_CommonAppData,
    ISpeechMMSysAudio, DISPID_SRGetRecognizers, DISPID_SRRTLength,
    SPSNotOverriden, SRAExport, _ULARGE_INTEGER, SAFTADPCM_8kHzMono,
    SPEI_FALSE_RECOGNITION, SPRST_INACTIVE, ISpShortcut,
    ISpSerializeState, SpNotifyTranslator, ISpLexicon, SRERequestUI,
    SP_VISEME_12, DISPID_SVEWord, SAFTCCITT_uLaw_22kHzMono, SPPS_Noun,
    IInternetSecurityMgrSite, DISPID_SPPValue, DISPID_SPACommit,
    SAFT44kHz16BitStereo, SAFT8kHz16BitMono,
    DISPID_SRSNumberOfActiveRules, SPLO_DYNAMIC,
    DISPID_SPIAudioSizeBytes, ISpRecoContext2, SDTReplacement,
    DISPID_SPARecoResult, DISPID_SPIAudioStreamPosition,
    SPEI_END_SR_STREAM, ISpNotifyTranslator, ISpeechGrammarRule,
    DISPID_SAFSetWaveFormatEx, SPEI_RECOGNITION,
    DISPID_SOTIsUISupported, DISPID_SVESentenceBoundary,
    SVEStartInputStream, DISPID_SLPLangId, eLEXTYPE_PRIVATE8,
    SpMMAudioIn, SAFTCCITT_ALaw_11kHzStereo, SRTSMLTimeout, SFTInput,
    SRESoundEnd, DISPID_SRGCmdLoadFromMemory, ISpEventSource,
    SAFTCCITT_uLaw_11kHzStereo, ISpeechPhraseProperty,
    DISPID_SPPParent, SPCT_SLEEP, DISPID_SOTCId,
    SAFTCCITT_uLaw_8kHzStereo, SLOStatic, SPSERIALIZEDRESULT,
    SGRSTTWildcard, DISPID_SRRTStreamTime, DISPID_SRDisplayUI,
    DISPID_SASCurrentDevicePosition, DISPID_SGRsItem,
    DISPID_SVSLastBookmarkId, SPEI_WORD_BOUNDARY, SPPHRASEELEMENT,
    SpResourceManager, SpeechEngineProperties, SP_VISEME_19,
    DISPID_SPRules_NewEnum, SP_VISEME_2, DISPID_SPCPhoneToId,
    DISPID_SGRsCommit, DISPID_SVSLastBookmark,
    SAFTCCITT_ALaw_22kHzStereo, DISPID_SVPause, SPPHRASERULE
)


class SPPARTOFSPEECH(IntFlag):
    SPPS_NotOverriden = -1
    SPPS_Unknown = 0
    SPPS_Noun = 4096
    SPPS_Verb = 8192
    SPPS_Modifier = 12288
    SPPS_Function = 16384
    SPPS_Interjection = 20480
    SPPS_Noncontent = 24576
    SPPS_LMA = 28672
    SPPS_SuppressWord = 61440


class DISPID_SpeechObjectTokens(IntFlag):
    DISPID_SOTsCount = 1
    DISPID_SOTsItem = 0
    DISPID_SOTs_NewEnum = -4


class DISPID_SpeechPhraseElement(IntFlag):
    DISPID_SPEAudioTimeOffset = 1
    DISPID_SPEAudioSizeTime = 2
    DISPID_SPEAudioStreamOffset = 3
    DISPID_SPEAudioSizeBytes = 4
    DISPID_SPERetainedStreamOffset = 5
    DISPID_SPERetainedSizeBytes = 6
    DISPID_SPEDisplayText = 7
    DISPID_SPELexicalForm = 8
    DISPID_SPEPronunciation = 9
    DISPID_SPEDisplayAttributes = 10
    DISPID_SPERequiredConfidence = 11
    DISPID_SPEActualConfidence = 12
    DISPID_SPEEngineConfidence = 13


class SpeechTokenContext(IntFlag):
    STCInprocServer = 1
    STCInprocHandler = 2
    STCLocalServer = 4
    STCRemoteServer = 16
    STCAll = 23


class SpeechTokenShellFolder(IntFlag):
    STSF_AppData = 26
    STSF_LocalAppData = 28
    STSF_CommonAppData = 35
    STSF_FlagCreate = 32768


class DISPID_SpeechObjectTokenCategory(IntFlag):
    DISPID_SOTCId = 1
    DISPID_SOTCDefault = 2
    DISPID_SOTCSetId = 3
    DISPID_SOTCGetDataKey = 4
    DISPID_SOTCEnumerateTokens = 5


class SpeechSpecialTransitionType(IntFlag):
    SSTTWildcard = 1
    SSTTDictation = 2
    SSTTTextBuffer = 3


class DISPID_SpeechRecoContextEvents(IntFlag):
    DISPID_SRCEStartStream = 1
    DISPID_SRCEEndStream = 2
    DISPID_SRCEBookmark = 3
    DISPID_SRCESoundStart = 4
    DISPID_SRCESoundEnd = 5
    DISPID_SRCEPhraseStart = 6
    DISPID_SRCERecognition = 7
    DISPID_SRCEHypothesis = 8
    DISPID_SRCEPropertyNumberChange = 9
    DISPID_SRCEPropertyStringChange = 10
    DISPID_SRCEFalseRecognition = 11
    DISPID_SRCEInterference = 12
    DISPID_SRCERequestUI = 13
    DISPID_SRCERecognizerStateChange = 14
    DISPID_SRCEAdaptation = 15
    DISPID_SRCERecognitionForOtherContext = 16
    DISPID_SRCEAudioLevel = 17
    DISPID_SRCEEnginePrivate = 18


class SpeechStreamSeekPositionType(IntFlag):
    SSSPTRelativeToStart = 0
    SSSPTRelativeToCurrentPosition = 1
    SSSPTRelativeToEnd = 2


class DISPID_SpeechAudioFormat(IntFlag):
    DISPID_SAFType = 1
    DISPID_SAFGuid = 2
    DISPID_SAFGetWaveFormatEx = 3
    DISPID_SAFSetWaveFormatEx = 4


class SPLEXICONTYPE(IntFlag):
    eLEXTYPE_USER = 1
    eLEXTYPE_APP = 2
    eLEXTYPE_VENDORLEXICON = 4
    eLEXTYPE_LETTERTOSOUND = 8
    eLEXTYPE_MORPHOLOGY = 16
    eLEXTYPE_RESERVED4 = 32
    eLEXTYPE_USER_SHORTCUT = 64
    eLEXTYPE_RESERVED6 = 128
    eLEXTYPE_RESERVED7 = 256
    eLEXTYPE_RESERVED8 = 512
    eLEXTYPE_RESERVED9 = 1024
    eLEXTYPE_RESERVED10 = 2048
    eLEXTYPE_PRIVATE1 = 4096
    eLEXTYPE_PRIVATE2 = 8192
    eLEXTYPE_PRIVATE3 = 16384
    eLEXTYPE_PRIVATE4 = 32768
    eLEXTYPE_PRIVATE5 = 65536
    eLEXTYPE_PRIVATE6 = 131072
    eLEXTYPE_PRIVATE7 = 262144
    eLEXTYPE_PRIVATE8 = 524288
    eLEXTYPE_PRIVATE9 = 1048576
    eLEXTYPE_PRIVATE10 = 2097152
    eLEXTYPE_PRIVATE11 = 4194304
    eLEXTYPE_PRIVATE12 = 8388608
    eLEXTYPE_PRIVATE13 = 16777216
    eLEXTYPE_PRIVATE14 = 33554432
    eLEXTYPE_PRIVATE15 = 67108864
    eLEXTYPE_PRIVATE16 = 134217728
    eLEXTYPE_PRIVATE17 = 268435456
    eLEXTYPE_PRIVATE18 = 536870912
    eLEXTYPE_PRIVATE19 = 1073741824
    eLEXTYPE_PRIVATE20 = -2147483648


class SPVPRIORITY(IntFlag):
    SPVPRI_NORMAL = 0
    SPVPRI_ALERT = 1
    SPVPRI_OVER = 2


class DISPID_SpeechBaseStream(IntFlag):
    DISPID_SBSFormat = 1
    DISPID_SBSRead = 2
    DISPID_SBSWrite = 3
    DISPID_SBSSeek = 4


class DISPID_SpeechPhraseElements(IntFlag):
    DISPID_SPEsCount = 1
    DISPID_SPEsItem = 0
    DISPID_SPEs_NewEnum = -4


class SpeechStreamFileMode(IntFlag):
    SSFMOpenForRead = 0
    SSFMOpenReadWrite = 1
    SSFMCreate = 2
    SSFMCreateForWrite = 3


class SpeechEngineConfidence(IntFlag):
    SECLowConfidence = -1
    SECNormalConfidence = 0
    SECHighConfidence = 1


class SPEVENTENUM(IntFlag):
    SPEI_UNDEFINED = 0
    SPEI_START_INPUT_STREAM = 1
    SPEI_END_INPUT_STREAM = 2
    SPEI_VOICE_CHANGE = 3
    SPEI_TTS_BOOKMARK = 4
    SPEI_WORD_BOUNDARY = 5
    SPEI_PHONEME = 6
    SPEI_SENTENCE_BOUNDARY = 7
    SPEI_VISEME = 8
    SPEI_TTS_AUDIO_LEVEL = 9
    SPEI_TTS_PRIVATE = 15
    SPEI_MIN_TTS = 1
    SPEI_MAX_TTS = 15
    SPEI_END_SR_STREAM = 34
    SPEI_SOUND_START = 35
    SPEI_SOUND_END = 36
    SPEI_PHRASE_START = 37
    SPEI_RECOGNITION = 38
    SPEI_HYPOTHESIS = 39
    SPEI_SR_BOOKMARK = 40
    SPEI_PROPERTY_NUM_CHANGE = 41
    SPEI_PROPERTY_STRING_CHANGE = 42
    SPEI_FALSE_RECOGNITION = 43
    SPEI_INTERFERENCE = 44
    SPEI_REQUEST_UI = 45
    SPEI_RECO_STATE_CHANGE = 46
    SPEI_ADAPTATION = 47
    SPEI_START_SR_STREAM = 48
    SPEI_RECO_OTHER_CONTEXT = 49
    SPEI_SR_AUDIO_LEVEL = 50
    SPEI_SR_RETAINEDAUDIO = 51
    SPEI_SR_PRIVATE = 52
    SPEI_ACTIVE_CATEGORY_CHANGED = 53
    SPEI_RESERVED5 = 54
    SPEI_RESERVED6 = 55
    SPEI_MIN_SR = 34
    SPEI_MAX_SR = 55
    SPEI_RESERVED1 = 30
    SPEI_RESERVED2 = 33
    SPEI_RESERVED3 = 63


class SpeechDataKeyLocation(IntFlag):
    SDKLDefaultLocation = 0
    SDKLCurrentUser = 1
    SDKLLocalMachine = 2
    SDKLCurrentConfig = 5


class SPAUDIOOPTIONS(IntFlag):
    SPAO_NONE = 0
    SPAO_RETAIN_AUDIO = 1


class SPBOOKMARKOPTIONS(IntFlag):
    SPBO_NONE = 0
    SPBO_PAUSE = 1
    SPBO_AHEAD = 2
    SPBO_TIME_UNITS = 4


class SPCONTEXTSTATE(IntFlag):
    SPCS_DISABLED = 0
    SPCS_ENABLED = 1


class DISPID_SpeechPhraseReplacement(IntFlag):
    DISPID_SPRDisplayAttributes = 1
    DISPID_SPRText = 2
    DISPID_SPRFirstElement = 3
    DISPID_SPRNumberOfElements = 4


class DISPID_SpeechAudio(IntFlag):
    DISPID_SAStatus = 200
    DISPID_SABufferInfo = 201
    DISPID_SADefaultFormat = 202
    DISPID_SAVolume = 203
    DISPID_SABufferNotifySize = 204
    DISPID_SAEventHandle = 205
    DISPID_SASetState = 206


class DISPID_SpeechPhraseReplacements(IntFlag):
    DISPID_SPRsCount = 1
    DISPID_SPRsItem = 0
    DISPID_SPRs_NewEnum = -4


class DISPID_SpeechGrammarRule(IntFlag):
    DISPID_SGRAttributes = 1
    DISPID_SGRInitialState = 2
    DISPID_SGRName = 3
    DISPID_SGRId = 4
    DISPID_SGRClear = 5
    DISPID_SGRAddResource = 6
    DISPID_SGRAddState = 7


class SpeechAudioFormatType(IntFlag):
    SAFTDefault = -1
    SAFTNoAssignedFormat = 0
    SAFTText = 1
    SAFTNonStandardFormat = 2
    SAFTExtendedAudioFormat = 3
    SAFT8kHz8BitMono = 4
    SAFT8kHz8BitStereo = 5
    SAFT8kHz16BitMono = 6
    SAFT8kHz16BitStereo = 7
    SAFT11kHz8BitMono = 8
    SAFT11kHz8BitStereo = 9
    SAFT11kHz16BitMono = 10
    SAFT11kHz16BitStereo = 11
    SAFT12kHz8BitMono = 12
    SAFT12kHz8BitStereo = 13
    SAFT12kHz16BitMono = 14
    SAFT12kHz16BitStereo = 15
    SAFT16kHz8BitMono = 16
    SAFT16kHz8BitStereo = 17
    SAFT16kHz16BitMono = 18
    SAFT16kHz16BitStereo = 19
    SAFT22kHz8BitMono = 20
    SAFT22kHz8BitStereo = 21
    SAFT22kHz16BitMono = 22
    SAFT22kHz16BitStereo = 23
    SAFT24kHz8BitMono = 24
    SAFT24kHz8BitStereo = 25
    SAFT24kHz16BitMono = 26
    SAFT24kHz16BitStereo = 27
    SAFT32kHz8BitMono = 28
    SAFT32kHz8BitStereo = 29
    SAFT32kHz16BitMono = 30
    SAFT32kHz16BitStereo = 31
    SAFT44kHz8BitMono = 32
    SAFT44kHz8BitStereo = 33
    SAFT44kHz16BitMono = 34
    SAFT44kHz16BitStereo = 35
    SAFT48kHz8BitMono = 36
    SAFT48kHz8BitStereo = 37
    SAFT48kHz16BitMono = 38
    SAFT48kHz16BitStereo = 39
    SAFTTrueSpeech_8kHz1BitMono = 40
    SAFTCCITT_ALaw_8kHzMono = 41
    SAFTCCITT_ALaw_8kHzStereo = 42
    SAFTCCITT_ALaw_11kHzMono = 43
    SAFTCCITT_ALaw_11kHzStereo = 44
    SAFTCCITT_ALaw_22kHzMono = 45
    SAFTCCITT_ALaw_22kHzStereo = 46
    SAFTCCITT_ALaw_44kHzMono = 47
    SAFTCCITT_ALaw_44kHzStereo = 48
    SAFTCCITT_uLaw_8kHzMono = 49
    SAFTCCITT_uLaw_8kHzStereo = 50
    SAFTCCITT_uLaw_11kHzMono = 51
    SAFTCCITT_uLaw_11kHzStereo = 52
    SAFTCCITT_uLaw_22kHzMono = 53
    SAFTCCITT_uLaw_22kHzStereo = 54
    SAFTCCITT_uLaw_44kHzMono = 55
    SAFTCCITT_uLaw_44kHzStereo = 56
    SAFTADPCM_8kHzMono = 57
    SAFTADPCM_8kHzStereo = 58
    SAFTADPCM_11kHzMono = 59
    SAFTADPCM_11kHzStereo = 60
    SAFTADPCM_22kHzMono = 61
    SAFTADPCM_22kHzStereo = 62
    SAFTADPCM_44kHzMono = 63
    SAFTADPCM_44kHzStereo = 64
    SAFTGSM610_8kHzMono = 65
    SAFTGSM610_11kHzMono = 66
    SAFTGSM610_22kHzMono = 67
    SAFTGSM610_44kHzMono = 68


class DISPID_SpeechMMSysAudio(IntFlag):
    DISPID_SMSADeviceId = 300
    DISPID_SMSALineId = 301
    DISPID_SMSAMMHandle = 302


class DISPID_SpeechPhraseProperty(IntFlag):
    DISPID_SPPName = 1
    DISPID_SPPId = 2
    DISPID_SPPValue = 3
    DISPID_SPPFirstElement = 4
    DISPID_SPPNumberOfElements = 5
    DISPID_SPPEngineConfidence = 6
    DISPID_SPPConfidence = 7
    DISPID_SPPParent = 8
    DISPID_SPPChildren = 9


class DISPID_SpeechRecognizerStatus(IntFlag):
    DISPID_SRSAudioStatus = 1
    DISPID_SRSCurrentStreamPosition = 2
    DISPID_SRSCurrentStreamNumber = 3
    DISPID_SRSNumberOfActiveRules = 4
    DISPID_SRSClsidEngine = 5
    DISPID_SRSSupportedLanguages = 6


class DISPID_SpeechFileStream(IntFlag):
    DISPID_SFSOpen = 100
    DISPID_SFSClose = 101


class DISPID_SpeechGrammarRules(IntFlag):
    DISPID_SGRsCount = 1
    DISPID_SGRsDynamic = 2
    DISPID_SGRsAdd = 3
    DISPID_SGRsCommit = 4
    DISPID_SGRsCommitAndSave = 5
    DISPID_SGRsFindRule = 6
    DISPID_SGRsItem = 0
    DISPID_SGRs_NewEnum = -4


class DISPID_SpeechCustomStream(IntFlag):
    DISPID_SCSBaseStream = 100


class DISPID_SpeechMemoryStream(IntFlag):
    DISPID_SMSSetData = 100
    DISPID_SMSGetData = 101


class DISPID_SpeechPhraseProperties(IntFlag):
    DISPID_SPPsCount = 1
    DISPID_SPPsItem = 0
    DISPID_SPPs_NewEnum = -4


class SpeechLoadOption(IntFlag):
    SLOStatic = 0
    SLODynamic = 1


class SpeechVoiceEvents(IntFlag):
    SVEStartInputStream = 2
    SVEEndInputStream = 4
    SVEVoiceChange = 8
    SVEBookmark = 16
    SVEWordBoundary = 32
    SVEPhoneme = 64
    SVESentenceBoundary = 128
    SVEViseme = 256
    SVEAudioLevel = 512
    SVEPrivate = 32768
    SVEAllEvents = 33790


class DISPID_SpeechAudioStatus(IntFlag):
    DISPID_SASFreeBufferSpace = 1
    DISPID_SASNonBlockingIO = 2
    DISPID_SASState = 3
    DISPID_SASCurrentSeekPosition = 4
    DISPID_SASCurrentDevicePosition = 5


class _SPAUDIOSTATE(IntFlag):
    SPAS_CLOSED = 0
    SPAS_STOP = 1
    SPAS_PAUSE = 2
    SPAS_RUN = 3


class DISPID_SpeechPhraseRule(IntFlag):
    DISPID_SPRuleName = 1
    DISPID_SPRuleId = 2
    DISPID_SPRuleFirstElement = 3
    DISPID_SPRuleNumberOfElements = 4
    DISPID_SPRuleParent = 5
    DISPID_SPRuleChildren = 6
    DISPID_SPRuleConfidence = 7
    DISPID_SPRuleEngineConfidence = 8


class SpeechVisemeFeature(IntFlag):
    SVF_None = 0
    SVF_Stressed = 1
    SVF_Emphasis = 2


class SpeechVisemeType(IntFlag):
    SVP_0 = 0
    SVP_1 = 1
    SVP_2 = 2
    SVP_3 = 3
    SVP_4 = 4
    SVP_5 = 5
    SVP_6 = 6
    SVP_7 = 7
    SVP_8 = 8
    SVP_9 = 9
    SVP_10 = 10
    SVP_11 = 11
    SVP_12 = 12
    SVP_13 = 13
    SVP_14 = 14
    SVP_15 = 15
    SVP_16 = 16
    SVP_17 = 17
    SVP_18 = 18
    SVP_19 = 19
    SVP_20 = 20
    SVP_21 = 21


class DISPID_SpeechAudioBufferInfo(IntFlag):
    DISPID_SABIMinNotification = 1
    DISPID_SABIBufferSize = 2
    DISPID_SABIEventBias = 3


class SpeechRuleState(IntFlag):
    SGDSInactive = 0
    SGDSActive = 1
    SGDSActiveWithAutoPause = 3
    SGDSActiveUserDelimited = 4


class DISPID_SpeechGrammarRuleStateTransitions(IntFlag):
    DISPID_SGRSTsCount = 1
    DISPID_SGRSTsItem = 0
    DISPID_SGRSTs_NewEnum = -4


class SpeechAudioState(IntFlag):
    SASClosed = 0
    SASStop = 1
    SASPause = 2
    SASRun = 3


class DISPID_SpeechWaveFormatEx(IntFlag):
    DISPID_SWFEFormatTag = 1
    DISPID_SWFEChannels = 2
    DISPID_SWFESamplesPerSec = 3
    DISPID_SWFEAvgBytesPerSec = 4
    DISPID_SWFEBlockAlign = 5
    DISPID_SWFEBitsPerSample = 6
    DISPID_SWFEExtraData = 7


class DISPID_SpeechPhraseRules(IntFlag):
    DISPID_SPRulesCount = 1
    DISPID_SPRulesItem = 0
    DISPID_SPRules_NewEnum = -4


class SpeechVoicePriority(IntFlag):
    SVPNormal = 0
    SVPAlert = 1
    SVPOver = 2


class DISPID_SpeechGrammarRuleStateTransition(IntFlag):
    DISPID_SGRSTType = 1
    DISPID_SGRSTText = 2
    DISPID_SGRSTRule = 3
    DISPID_SGRSTWeight = 4
    DISPID_SGRSTPropertyName = 5
    DISPID_SGRSTPropertyId = 6
    DISPID_SGRSTPropertyValue = 7
    DISPID_SGRSTNextState = 8


class SpeechVoiceSpeakFlags(IntFlag):
    SVSFDefault = 0
    SVSFlagsAsync = 1
    SVSFPurgeBeforeSpeak = 2
    SVSFIsFilename = 4
    SVSFIsXML = 8
    SVSFIsNotXML = 16
    SVSFPersistXML = 32
    SVSFNLPSpeakPunc = 64
    SVSFParseSapi = 128
    SVSFParseSsml = 256
    SVSFParseAutodetect = 0
    SVSFNLPMask = 64
    SVSFParseMask = 384
    SVSFVoiceMask = 511
    SVSFUnusedFlags = -512


class DISPID_SpeechLexicon(IntFlag):
    DISPID_SLGenerationId = 1
    DISPID_SLGetWords = 2
    DISPID_SLAddPronunciation = 3
    DISPID_SLAddPronunciationByPhoneIds = 4
    DISPID_SLRemovePronunciation = 5
    DISPID_SLRemovePronunciationByPhoneIds = 6
    DISPID_SLGetPronunciations = 7
    DISPID_SLGetGenerationChange = 8


class DISPID_SpeechVoice(IntFlag):
    DISPID_SVStatus = 1
    DISPID_SVVoice = 2
    DISPID_SVAudioOutput = 3
    DISPID_SVAudioOutputStream = 4
    DISPID_SVRate = 5
    DISPID_SVVolume = 6
    DISPID_SVAllowAudioOuputFormatChangesOnNextSet = 7
    DISPID_SVEventInterests = 8
    DISPID_SVPriority = 9
    DISPID_SVAlertBoundary = 10
    DISPID_SVSyncronousSpeakTimeout = 11
    DISPID_SVSpeak = 12
    DISPID_SVSpeakStream = 13
    DISPID_SVPause = 14
    DISPID_SVResume = 15
    DISPID_SVSkip = 16
    DISPID_SVGetVoices = 17
    DISPID_SVGetAudioOutputs = 18
    DISPID_SVWaitUntilDone = 19
    DISPID_SVSpeakCompleteEvent = 20
    DISPID_SVIsUISupported = 21
    DISPID_SVDisplayUI = 22


class DISPIDSPTSI(IntFlag):
    DISPIDSPTSI_ActiveOffset = 1
    DISPIDSPTSI_ActiveLength = 2
    DISPIDSPTSI_SelectionOffset = 3
    DISPIDSPTSI_SelectionLength = 4


class DISPID_SpeechLexiconWords(IntFlag):
    DISPID_SLWsCount = 1
    DISPID_SLWsItem = 0
    DISPID_SLWs_NewEnum = -4


class DISPID_SpeechRecoResult(IntFlag):
    DISPID_SRRRecoContext = 1
    DISPID_SRRTimes = 2
    DISPID_SRRAudioFormat = 3
    DISPID_SRRPhraseInfo = 4
    DISPID_SRRAlternates = 5
    DISPID_SRRAudio = 6
    DISPID_SRRSpeakAudio = 7
    DISPID_SRRSaveToMemory = 8
    DISPID_SRRDiscardResultInfo = 9


class DISPID_SpeechLexiconWord(IntFlag):
    DISPID_SLWLangId = 1
    DISPID_SLWType = 2
    DISPID_SLWWord = 3
    DISPID_SLWPronunciations = 4


class DISPID_SpeechLexiconProns(IntFlag):
    DISPID_SLPsCount = 1
    DISPID_SLPsItem = 0
    DISPID_SLPs_NewEnum = -4


class SpeechWordPronounceable(IntFlag):
    SWPUnknownWordUnpronounceable = 0
    SWPUnknownWordPronounceable = 1
    SWPKnownWordPronounceable = 2


class DISPID_SpeechXMLRecoResult(IntFlag):
    DISPID_SRRGetXMLResult = 10
    DISPID_SRRGetXMLErrorInfo = 11


class DISPID_SpeechLexiconPronunciation(IntFlag):
    DISPID_SLPType = 1
    DISPID_SLPLangId = 2
    DISPID_SLPPartOfSpeech = 3
    DISPID_SLPPhoneIds = 4
    DISPID_SLPSymbolic = 5


class SPRECOSTATE(IntFlag):
    SPRST_INACTIVE = 0
    SPRST_ACTIVE = 1
    SPRST_ACTIVE_ALWAYS = 2
    SPRST_INACTIVE_WITH_PURGE = 3
    SPRST_NUM_STATES = 4


class SPWAVEFORMATTYPE(IntFlag):
    SPWF_INPUT = 0
    SPWF_SRENGINE = 1


class SPWORDTYPE(IntFlag):
    eWORDTYPE_ADDED = 1
    eWORDTYPE_DELETED = 2


class SpeechDiscardType(IntFlag):
    SDTProperty = 1
    SDTReplacement = 2
    SDTRule = 4
    SDTDisplayText = 8
    SDTLexicalForm = 16
    SDTPronunciation = 32
    SDTAudio = 64
    SDTAlternates = 128
    SDTAll = 255


class SPXMLRESULTOPTIONS(IntFlag):
    SPXRO_SML = 0
    SPXRO_Alternates_SML = 1


class DISPID_SpeechVoiceStatus(IntFlag):
    DISPID_SVSCurrentStreamNumber = 1
    DISPID_SVSLastStreamNumberQueued = 2
    DISPID_SVSLastResult = 3
    DISPID_SVSRunningState = 4
    DISPID_SVSInputWordPosition = 5
    DISPID_SVSInputWordLength = 6
    DISPID_SVSInputSentencePosition = 7
    DISPID_SVSInputSentenceLength = 8
    DISPID_SVSLastBookmark = 9
    DISPID_SVSLastBookmarkId = 10
    DISPID_SVSPhonemeId = 11
    DISPID_SVSVisemeId = 12


class SpeechRecognizerState(IntFlag):
    SRSInactive = 0
    SRSActive = 1
    SRSActiveAlways = 2
    SRSInactiveWithPurge = 3


class SpeechFormatType(IntFlag):
    SFTInput = 0
    SFTSREngine = 1


class DISPID_SpeechPhoneConverter(IntFlag):
    DISPID_SPCLangId = 1
    DISPID_SPCPhoneToId = 2
    DISPID_SPCIdToPhone = 3


class SPFILEMODE(IntFlag):
    SPFM_OPEN_READONLY = 0
    SPFM_OPEN_READWRITE = 1
    SPFM_CREATE = 2
    SPFM_CREATE_ALWAYS = 3
    SPFM_NUM_MODES = 4


class DISPID_SpeechVoiceEvent(IntFlag):
    DISPID_SVEStreamStart = 1
    DISPID_SVEStreamEnd = 2
    DISPID_SVEVoiceChange = 3
    DISPID_SVEBookmark = 4
    DISPID_SVEWord = 5
    DISPID_SVEPhoneme = 6
    DISPID_SVESentenceBoundary = 7
    DISPID_SVEViseme = 8
    DISPID_SVEAudioLevel = 9
    DISPID_SVEEnginePrivate = 10


class SPLOADOPTIONS(IntFlag):
    SPLO_STATIC = 0
    SPLO_DYNAMIC = 1


class SPSHORTCUTTYPE(IntFlag):
    SPSHT_NotOverriden = -1
    SPSHT_Unknown = 0
    SPSHT_EMAIL = 4096
    SPSHT_OTHER = 8192
    SPPS_RESERVED1 = 12288
    SPPS_RESERVED2 = 16384
    SPPS_RESERVED3 = 20480
    SPPS_RESERVED4 = 61440


class DISPID_SpeechRecognizer(IntFlag):
    DISPID_SRRecognizer = 1
    DISPID_SRAllowAudioInputFormatChangesOnNextSet = 2
    DISPID_SRAudioInput = 3
    DISPID_SRAudioInputStream = 4
    DISPID_SRIsShared = 5
    DISPID_SRState = 6
    DISPID_SRStatus = 7
    DISPID_SRProfile = 8
    DISPID_SREmulateRecognition = 9
    DISPID_SRCreateRecoContext = 10
    DISPID_SRGetFormat = 11
    DISPID_SRSetPropertyNumber = 12
    DISPID_SRGetPropertyNumber = 13
    DISPID_SRSetPropertyString = 14
    DISPID_SRGetPropertyString = 15
    DISPID_SRIsUISupported = 16
    DISPID_SRDisplayUI = 17
    DISPID_SRGetRecognizers = 18
    DISPID_SVGetAudioInputs = 19
    DISPID_SVGetProfiles = 20


class DISPID_SpeechRecoResult2(IntFlag):
    DISPID_SRRSetTextFeedback = 12


class SpeechDisplayAttributes(IntFlag):
    SDA_No_Trailing_Space = 0
    SDA_One_Trailing_Space = 2
    SDA_Two_Trailing_Spaces = 4
    SDA_Consume_Leading_Spaces = 8


class SpeechRunState(IntFlag):
    SRSEDone = 1
    SRSEIsSpeaking = 2


class SpeechEmulationCompareFlags(IntFlag):
    SECFIgnoreCase = 1
    SECFIgnoreKanaType = 65536
    SECFIgnoreWidth = 131072
    SECFNoSpecialChars = 536870912
    SECFEmulateResult = 1073741824
    SECFDefault = 196609


class SPVISEMES(IntFlag):
    SP_VISEME_0 = 0
    SP_VISEME_1 = 1
    SP_VISEME_2 = 2
    SP_VISEME_3 = 3
    SP_VISEME_4 = 4
    SP_VISEME_5 = 5
    SP_VISEME_6 = 6
    SP_VISEME_7 = 7
    SP_VISEME_8 = 8
    SP_VISEME_9 = 9
    SP_VISEME_10 = 10
    SP_VISEME_11 = 11
    SP_VISEME_12 = 12
    SP_VISEME_13 = 13
    SP_VISEME_14 = 14
    SP_VISEME_15 = 15
    SP_VISEME_16 = 16
    SP_VISEME_17 = 17
    SP_VISEME_18 = 18
    SP_VISEME_19 = 19
    SP_VISEME_20 = 20
    SP_VISEME_21 = 21


class DISPID_SpeechPhraseAlternate(IntFlag):
    DISPID_SPARecoResult = 1
    DISPID_SPAStartElementInResult = 2
    DISPID_SPANumberOfElementsInResult = 3
    DISPID_SPAPhraseInfo = 4
    DISPID_SPACommit = 5


class SPSEMANTICFORMAT(IntFlag):
    SPSMF_SAPI_PROPERTIES = 0
    SPSMF_SRGS_SEMANTICINTERPRETATION_MS = 1
    SPSMF_SRGS_SAPIPROPERTIES = 2
    SPSMF_UPS = 4
    SPSMF_SRGS_SEMANTICINTERPRETATION_W3C = 8


class DISPID_SpeechPhraseAlternates(IntFlag):
    DISPID_SPAsCount = 1
    DISPID_SPAsItem = 0
    DISPID_SPAs_NewEnum = -4


class DISPID_SpeechPhraseInfo(IntFlag):
    DISPID_SPILanguageId = 1
    DISPID_SPIGrammarId = 2
    DISPID_SPIStartTime = 3
    DISPID_SPIAudioStreamPosition = 4
    DISPID_SPIAudioSizeBytes = 5
    DISPID_SPIRetainedSizeBytes = 6
    DISPID_SPIAudioSizeTime = 7
    DISPID_SPIRule = 8
    DISPID_SPIProperties = 9
    DISPID_SPIElements = 10
    DISPID_SPIReplacements = 11
    DISPID_SPIEngineId = 12
    DISPID_SPIEnginePrivateData = 13
    DISPID_SPISaveToMemory = 14
    DISPID_SPIGetText = 15
    DISPID_SPIGetDisplayAttributes = 16


class DISPID_SpeechRecoResultTimes(IntFlag):
    DISPID_SRRTStreamTime = 1
    DISPID_SRRTLength = 2
    DISPID_SRRTTickCount = 3
    DISPID_SRRTOffsetFromStart = 4


class DISPIDSPRG(IntFlag):
    DISPID_SRGId = 1
    DISPID_SRGRecoContext = 2
    DISPID_SRGState = 3
    DISPID_SRGRules = 4
    DISPID_SRGReset = 5
    DISPID_SRGCommit = 6
    DISPID_SRGCmdLoadFromFile = 7
    DISPID_SRGCmdLoadFromObject = 8
    DISPID_SRGCmdLoadFromResource = 9
    DISPID_SRGCmdLoadFromMemory = 10
    DISPID_SRGCmdLoadFromProprietaryGrammar = 11
    DISPID_SRGCmdSetRuleState = 12
    DISPID_SRGCmdSetRuleIdState = 13
    DISPID_SRGDictationLoad = 14
    DISPID_SRGDictationUnload = 15
    DISPID_SRGDictationSetState = 16
    DISPID_SRGSetWordSequenceData = 17
    DISPID_SRGSetTextSelection = 18
    DISPID_SRGIsPronounceable = 19


class SPRULESTATE(IntFlag):
    SPRS_INACTIVE = 0
    SPRS_ACTIVE = 1
    SPRS_ACTIVE_WITH_AUTO_PAUSE = 3
    SPRS_ACTIVE_USER_DELIMITED = 4


class SPDATAKEYLOCATION(IntFlag):
    SPDKL_DefaultLocation = 0
    SPDKL_CurrentUser = 1
    SPDKL_LocalMachine = 2
    SPDKL_CurrentConfig = 5


class SpeechRecoContextState(IntFlag):
    SRCS_Disabled = 0
    SRCS_Enabled = 1


class SpeechRetainedAudioOptions(IntFlag):
    SRAONone = 0
    SRAORetainAudio = 1


class DISPID_SpeechRecoContext(IntFlag):
    DISPID_SRCRecognizer = 1
    DISPID_SRCAudioInInterferenceStatus = 2
    DISPID_SRCRequestedUIType = 3
    DISPID_SRCVoice = 4
    DISPID_SRAllowVoiceFormatMatchingOnNextSet = 5
    DISPID_SRCVoicePurgeEvent = 6
    DISPID_SRCEventInterests = 7
    DISPID_SRCCmdMaxAlternates = 8
    DISPID_SRCState = 9
    DISPID_SRCRetainedAudio = 10
    DISPID_SRCRetainedAudioFormat = 11
    DISPID_SRCPause = 12
    DISPID_SRCResume = 13
    DISPID_SRCCreateGrammar = 14
    DISPID_SRCCreateResultFromMemory = 15
    DISPID_SRCBookmark = 16
    DISPID_SRCSetAdaptationData = 17


class SPWORDPRONOUNCEABLE(IntFlag):
    SPWP_UNKNOWN_WORD_UNPRONOUNCEABLE = 0
    SPWP_UNKNOWN_WORD_PRONOUNCEABLE = 1
    SPWP_KNOWN_WORD_PRONOUNCEABLE = 2


class SpeechRecognitionType(IntFlag):
    SRTStandard = 0
    SRTAutopause = 1
    SRTEmulated = 2
    SRTSMLTimeout = 4
    SRTExtendableParse = 8
    SRTReSent = 16


class DISPID_SpeechGrammarRuleState(IntFlag):
    DISPID_SGRSRule = 1
    DISPID_SGRSTransitions = 2
    DISPID_SGRSAddWordTransition = 3
    DISPID_SGRSAddRuleTransition = 4
    DISPID_SGRSAddSpecialTransition = 5


class SpeechBookmarkOptions(IntFlag):
    SBONone = 0
    SBOPause = 1


class SpeechInterference(IntFlag):
    SINone = 0
    SINoise = 1
    SINoSignal = 2
    SITooLoud = 3
    SITooQuiet = 4
    SITooFast = 5
    SITooSlow = 6


class SPGRAMMARSTATE(IntFlag):
    SPGS_DISABLED = 0
    SPGS_ENABLED = 1
    SPGS_EXCLUSIVE = 3


class SpeechGrammarState(IntFlag):
    SGSEnabled = 1
    SGSDisabled = 0
    SGSExclusive = 3


class SpeechRecoEvents(IntFlag):
    SREStreamEnd = 1
    SRESoundStart = 2
    SRESoundEnd = 4
    SREPhraseStart = 8
    SRERecognition = 16
    SREHypothesis = 32
    SREBookmark = 64
    SREPropertyNumChange = 128
    SREPropertyStringChange = 256
    SREFalseRecognition = 512
    SREInterference = 1024
    SRERequestUI = 2048
    SREStateChange = 4096
    SREAdaptation = 8192
    SREStreamStart = 16384
    SRERecoOtherContext = 32768
    SREAudioLevel = 65536
    SREPrivate = 262144
    SREAllEvents = 393215


class SPCATEGORYTYPE(IntFlag):
    SPCT_COMMAND = 0
    SPCT_DICTATION = 1
    SPCT_SLEEP = 2
    SPCT_SUB_COMMAND = 3
    SPCT_SUB_DICTATION = 4


class SPINTERFERENCE(IntFlag):
    SPINTERFERENCE_NONE = 0
    SPINTERFERENCE_NOISE = 1
    SPINTERFERENCE_NOSIGNAL = 2
    SPINTERFERENCE_TOOLOUD = 3
    SPINTERFERENCE_TOOQUIET = 4
    SPINTERFERENCE_TOOFAST = 5
    SPINTERFERENCE_TOOSLOW = 6
    SPINTERFERENCE_LATENCY_WARNING = 7
    SPINTERFERENCE_LATENCY_TRUNCATE_BEGIN = 8
    SPINTERFERENCE_LATENCY_TRUNCATE_END = 9


class SpeechLexiconType(IntFlag):
    SLTUser = 1
    SLTApp = 2


class SpeechRuleAttributes(IntFlag):
    SRATopLevel = 1
    SRADefaultToActive = 2
    SRAExport = 4
    SRAImport = 8
    SRAInterpreter = 16
    SRADynamic = 32
    SRARoot = 64


class DISPID_SpeechPhraseBuilder(IntFlag):
    DISPID_SPPBRestorePhraseFromMemory = 1


class SPADAPTATIONRELEVANCE(IntFlag):
    SPAR_Unknown = 0
    SPAR_Low = 1
    SPAR_Medium = 2
    SPAR_High = 3


class SpeechWordType(IntFlag):
    SWTAdded = 1
    SWTDeleted = 2


class SpeechGrammarWordType(IntFlag):
    SGDisplay = 0
    SGLexical = 1
    SGPronounciation = 2
    SGLexicalNoSpecialChars = 3


class SpeechPartOfSpeech(IntFlag):
    SPSNotOverriden = -1
    SPSUnknown = 0
    SPSNoun = 4096
    SPSVerb = 8192
    SPSModifier = 12288
    SPSFunction = 16384
    SPSInterjection = 20480
    SPSLMA = 28672
    SPSSuppressWord = 61440


class SPGRAMMARWORDTYPE(IntFlag):
    SPWT_DISPLAY = 0
    SPWT_LEXICAL = 1
    SPWT_PRONUNCIATION = 2
    SPWT_LEXICAL_NO_SPECIAL_CHARS = 3


class SpeechGrammarRuleStateTransitionType(IntFlag):
    SGRSTTEpsilon = 0
    SGRSTTWord = 1
    SGRSTTRule = 2
    SGRSTTDictation = 3
    SGRSTTWildcard = 4
    SGRSTTTextBuffer = 5


class DISPID_SpeechDataKey(IntFlag):
    DISPID_SDKSetBinaryValue = 1
    DISPID_SDKGetBinaryValue = 2
    DISPID_SDKSetStringValue = 3
    DISPID_SDKGetStringValue = 4
    DISPID_SDKSetLongValue = 5
    DISPID_SDKGetlongValue = 6
    DISPID_SDKOpenKey = 7
    DISPID_SDKCreateKey = 8
    DISPID_SDKDeleteKey = 9
    DISPID_SDKDeleteValue = 10
    DISPID_SDKEnumKeys = 11
    DISPID_SDKEnumValues = 12


class DISPID_SpeechObjectToken(IntFlag):
    DISPID_SOTId = 1
    DISPID_SOTDataKey = 2
    DISPID_SOTCategory = 3
    DISPID_SOTGetDescription = 4
    DISPID_SOTSetId = 5
    DISPID_SOTGetAttribute = 6
    DISPID_SOTCreateInstance = 7
    DISPID_SOTRemove = 8
    DISPID_SOTGetStorageFileName = 9
    DISPID_SOTRemoveStorageFileName = 10
    DISPID_SOTIsUISupported = 11
    DISPID_SOTDisplayUI = 12
    DISPID_SOTMatchesAttributes = 13


SPAUDIOSTATE = _SPAUDIOSTATE
SPSTREAMFORMATTYPE = SPWAVEFORMATTYPE


__all__ = [
    'SPLEXICONTYPE', 'ISpeechDataKey', 'DISPID_SGRSTRule',
    'DISPID_SRRPhraseInfo', 'eLEXTYPE_PRIVATE15',
    'DISPID_SRGDictationUnload', 'SPEI_MIN_TTS', 'SVP_13',
    'SVF_Stressed', 'SVP_7', 'SpeechGrammarWordType', 'SP_VISEME_18',
    'SWPKnownWordPronounceable', 'SAFTADPCM_11kHzStereo',
    'DISPID_SVAlertBoundary', 'SPEI_RESERVED3', 'ISpRecoCategory',
    'DISPID_SRGCmdSetRuleState', 'ISpStream',
    'DISPID_SDKSetStringValue', 'ISpeechBaseStream',
    'DISPID_SWFESamplesPerSec', 'SPRECOSTATE', 'SPGS_EXCLUSIVE',
    'SpeechVoicePriority', 'SPSERIALIZEDPHRASE', 'DISPID_SAVolume',
    'DISPID_SpeechPhraseBuilder', 'SPWORDPRONOUNCEABLE', 'SWTAdded',
    'DISPID_SBSWrite', 'SRESoundStart', 'eWORDTYPE_DELETED',
    'DISPID_SpeechGrammarRuleStateTransition',
    'DISPID_SRCCmdMaxAlternates', 'SpPhraseInfoBuilder',
    'SPCONTEXTSTATE', 'DISPID_SLGetWords', 'SPRECOGNIZERSTATUS',
    'SpPhoneticAlphabetConverter', 'DISPID_SPPsCount',
    'eLEXTYPE_PRIVATE2', 'DISPID_SPCIdToPhone',
    'SPEI_RECO_OTHER_CONTEXT', 'SASRun', 'DISPID_SVRate',
    'SDA_Consume_Leading_Spaces', 'SP_VISEME_7', 'SVP_9',
    'SGRSTTEpsilon', 'SpeechTokenKeyUI', 'DISPID_SADefaultFormat',
    'SPPS_RESERVED4', 'DISPID_SPEAudioSizeTime', 'ISpeechRecoResult2',
    'SVSFParseAutodetect', 'DISPID_SVEBookmark', 'ISpEventSink',
    'SAFTGSM610_11kHzMono', 'SpeechPropertyAdaptationOn',
    'DISPID_SRGCmdSetRuleIdState', 'STCRemoteServer',
    'SVSFIsFilename', 'DISPID_SRGetPropertyNumber',
    'DISPID_SVSRunningState', 'SPRST_INACTIVE_WITH_PURGE',
    'DISPID_SPIElements', 'SPRS_ACTIVE', 'DISPID_SDKSetBinaryValue',
    'STCInprocHandler', 'SPEI_PROPERTY_STRING_CHANGE',
    'SPBOOKMARKOPTIONS', 'DISPID_SpeechPhraseRules',
    'DISPID_SLWsItem', 'eLEXTYPE_RESERVED7', 'SVEAllEvents',
    'ISpRecoContext', 'SPSHT_NotOverriden', 'SAFT12kHz8BitMono',
    'SPPS_RESERVED3', 'DISPID_SGRInitialState', 'ISpVoice',
    'SRSActive', 'SPLOADOPTIONS', 'SPBINARYGRAMMAR',
    'SRERecoOtherContext', 'SAFTGSM610_8kHzMono', 'SAFT48kHz8BitMono',
    'DISPID_SASNonBlockingIO', 'ISpAudio', 'SVSFParseMask',
    'DISPID_SAFType', 'ISpPhoneConverter',
    'DISPID_SRRTOffsetFromStart', 'SPDKL_CurrentUser',
    'DISPID_SpeechPhraseElement',
    'DISPID_SRCERecognitionForOtherContext', 'DISPID_SRCEEndStream',
    'SVEViseme', 'SpeechPropertyNormalConfidenceThreshold',
    'ISpPhoneticAlphabetSelection', 'SpeechInterference', 'SVP_21',
    'SPSEMANTICFORMAT', 'SDKLDefaultLocation',
    'DISPID_SRCRequestedUIType', 'SRCS_Disabled', 'DISPID_SASState',
    'DISPID_SVVolume', 'SPPS_RESERVED1', 'SDTPronunciation',
    'SPWT_DISPLAY', 'SPLO_STATIC', 'SVP_19', 'Library',
    'SPCS_ENABLED', 'SDTRule', 'SAFT16kHz16BitMono',
    'DISPID_SVEStreamStart', 'SAFTExtendedAudioFormat',
    'SPEI_ACTIVE_CATEGORY_CHANGED', 'SPINTERFERENCE_TOOQUIET',
    'DISPID_SOTCGetDataKey', 'SAFTADPCM_11kHzMono',
    'DISPID_SpeechPhraseProperty', 'SPEI_SR_BOOKMARK',
    'SAFTCCITT_uLaw_44kHzStereo', 'tagSPTEXTSELECTIONINFO',
    'DISPID_SRRGetXMLErrorInfo', 'DISPID_SLPsCount',
    'DISPID_SRCEStartStream', 'ISpeechPhraseRules', 'SWTDeleted',
    'SVPAlert', 'DISPID_SpeechBaseStream', 'SPAR_High',
    'SDKLLocalMachine', 'SPVISEMES', 'eLEXTYPE_RESERVED9',
    'SPINTERFERENCE_LATENCY_WARNING', 'DISPID_SRGId',
    'DISPID_SOTCEnumerateTokens', 'DISPID_SPIEngineId',
    'SREStreamStart', 'DISPID_SFSOpen', 'eLEXTYPE_PRIVATE18',
    'DISPID_SLGetGenerationChange', 'SPSHT_Unknown',
    'DISPID_SpeechAudioStatus', 'SBONone', 'SPSHORTCUTPAIRLIST',
    'SREAdaptation', 'SVP_14', 'SPRS_ACTIVE_USER_DELIMITED',
    'IEnumString', 'DISPID_SMSAMMHandle', 'DISPID_SRCEventInterests',
    'SPVOICESTATUS', 'DISPID_SpeechMMSysAudio', 'ISpRecognizer2',
    'SVEVoiceChange', 'SVSFParseSapi', 'SPWT_PRONUNCIATION',
    'SPDATAKEYLOCATION', 'DISPID_SVGetVoices', 'SSTTDictation',
    'SRARoot', 'SpeechMicTraining', 'DISPID_SASetState',
    'SVESentenceBoundary', 'SVSFNLPMask', 'DISPID_SPPConfidence',
    'SPWP_UNKNOWN_WORD_PRONOUNCEABLE', 'SpeechTokenKeyAttributes',
    'DISPID_SLRemovePronunciationByPhoneIds',
    'DISPID_SPIAudioSizeTime', 'DISPID_SRCEAudioLevel',
    'ISpeechVoiceStatus', 'DISPID_SPERetainedSizeBytes',
    'DISPID_SVStatus', 'DISPID_SVSInputWordLength',
    'ISpResourceManager', 'SPRST_ACTIVE', 'ISpeechPhraseReplacements',
    'UINT_PTR', 'Speech_StreamPos_Asap', 'SDKLCurrentConfig',
    'DISPID_SABIBufferSize', 'DISPID_SRRSaveToMemory',
    'DISPID_SRCreateRecoContext', 'DISPID_SLPPhoneIds',
    'SpeechRecoContextState', 'DISPID_SBSSeek', 'SVSFIsNotXML',
    'SRTAutopause', 'SRAImport', 'DISPID_SVVoice',
    'SAFT48kHz8BitStereo', '__MIDL_IWinTypes_0009',
    'DISPIDSPTSI_ActiveLength', 'SDTAlternates', 'SPGRAMMARSTATE',
    'DISPID_SCSBaseStream', 'SAFTCCITT_uLaw_22kHzStereo',
    'DISPID_SRCEPropertyStringChange', 'DISPID_SPRuleParent',
    'DISPID_SGRSTPropertyId', 'ISpGrammarBuilder',
    'ISpeechPhoneConverter', 'SPINTERFERENCE_LATENCY_TRUNCATE_END',
    'DISPID_SGRAttributes', 'DISPID_SpeechXMLRecoResult',
    'DISPID_SRCEPhraseStart', 'DISPID_SRRSpeakAudio',
    'SPWAVEFORMATTYPE', 'DISPID_SMSALineId', 'SVP_12',
    'SPFM_OPEN_READONLY', 'SSFMCreateForWrite', 'SECFIgnoreCase',
    'SPGS_ENABLED', 'ISpeechPhraseAlternate', 'SPSEMANTICERRORINFO',
    'SP_VISEME_16', 'SRCS_Enabled', 'ISpPhrase', 'SPPS_Verb',
    'SSSPTRelativeToEnd', 'SPEI_REQUEST_UI', 'DISPID_SpeechVoice',
    'SPPS_NotOverriden', 'DISPID_SWFEAvgBytesPerSec',
    'DISPID_SLWsCount', 'DISPID_SGRSAddRuleTransition',
    'DISPID_SRRAudio', 'SPRULE', 'Speech_Max_Pron_Length',
    'SECFEmulateResult', 'DISPID_SPERequiredConfidence',
    'SpeechDataKeyLocation', 'SDTDisplayText', 'SDTLexicalForm',
    'SpeechVoiceSkipTypeSentence', 'DISPID_SpeechGrammarRuleState',
    'DISPID_SRCEPropertyNumberChange', 'SSFMOpenReadWrite',
    'SWPUnknownWordUnpronounceable', 'DISPID_SRCEAdaptation',
    'DISPID_SRSCurrentStreamNumber', 'SPAR_Medium',
    'SpeechGrammarRuleStateTransitionType', 'DISPID_SRRTTickCount',
    'SVP_17', 'DISPID_SGRId', 'DISPID_SpeechGrammarRules',
    'DISPID_SRCCreateResultFromMemory', 'SPVPRI_OVER',
    '__MIDL___MIDL_itf_sapi_0000_0020_0002', 'SpeechAudioState',
    'DISPID_SPIReplacements', 'ISpeechLexiconPronunciation',
    'DISPID_SPRsCount', 'SPEI_START_INPUT_STREAM',
    'SpeechRegistryUserRoot', 'DISPID_SRGRecoContext',
    'SAFT11kHz16BitMono', 'SAFTNoAssignedFormat', 'SAFT24kHz8BitMono',
    'SREPropertyNumChange', 'SpNullPhoneConverter',
    'SpeechRecognitionType', 'DISPID_SRAudioInput', 'SGSEnabled',
    'SPEI_MIN_SR', 'DISPID_SpeechRecognizerStatus', 'SREInterference',
    'SpLexicon', 'SGDisplay', 'DISPID_SRSCurrentStreamPosition',
    'IEnumSpObjectTokens', 'SPEI_RECO_STATE_CHANGE',
    'SPINTERFERENCE_LATENCY_TRUNCATE_BEGIN', 'DISPID_SPISaveToMemory',
    'SVP_4', 'SAFT32kHz16BitStereo', 'SPPS_RESERVED2', 'SPSMF_UPS',
    'SPWT_LEXICAL_NO_SPECIAL_CHARS', 'SGPronounciation',
    'DISPID_SRCRetainedAudioFormat', 'DISPID_SpeechLexiconProns',
    'SPPHRASEPROPERTY', 'SPEI_TTS_PRIVATE', 'SRSEDone', 'SVP_20',
    'SpeechCategoryVoices', 'DISPID_SWFEFormatTag', 'SVP_15',
    'SPPARTOFSPEECH', 'DISPID_SPIStartTime', 'SVP_5',
    'DISPID_SPEPronunciation', 'SVEAudioLevel',
    'DISPID_SRCESoundStart', 'SVSFDefault', 'SPWORD',
    'DISPID_SRCPause', 'SpeechPropertyHighConfidenceThreshold',
    'SPPROPERTYINFO', 'SpUnCompressedLexicon', 'SINoSignal',
    'SAFT24kHz8BitStereo', 'SAFTCCITT_ALaw_44kHzStereo',
    'SpeechWordPronounceable', 'SITooSlow',
    'SpeechDictationTopicSpelling', 'SASStop',
    'DISPIDSPTSI_SelectionOffset', 'SPEI_PHRASE_START',
    'IInternetSecurityManager', 'SPDKL_DefaultLocation',
    'SpeechGrammarState', 'ISpeechPhraseAlternates',
    'SpeechRetainedAudioOptions', 'SLTApp', 'SpeechVoiceEvents',
    'SPFM_CREATE_ALWAYS', 'SPBO_PAUSE', 'DISPID_SLGenerationId',
    'SREPrivate', 'SAFTCCITT_ALaw_8kHzStereo', 'ISpStreamFormat',
    'SAFT44kHz8BitStereo', 'typelib_path', 'SVP_10',
    'DISPID_SVGetAudioOutputs', 'SpeechRuleAttributes',
    'SECHighConfidence', 'DISPID_SRGetPropertyString',
    'DISPID_SPIRetainedSizeBytes', 'DISPID_SVSCurrentStreamNumber',
    'DISPID_SpeechDataKey', 'DISPID_SOTCreateInstance',
    'SPEI_PROPERTY_NUM_CHANGE', 'SP_VISEME_20', 'DISPID_SWFEChannels',
    'DISPID_SPPs_NewEnum', 'SPSTREAMFORMATTYPE',
    'SpStreamFormatConverter', 'DISPID_SPRsItem',
    'ISpObjectWithToken', 'DISPID_SVIsUISupported', 'SECFIgnoreWidth',
    'DISPID_SVSpeak', 'DISPID_SOTMatchesAttributes',
    'DISPID_SVSLastStreamNumberQueued', 'DISPID_SpeechAudio',
    'SPRULESTATE', 'DISPID_SWFEExtraData', 'ISpeechRecognizer',
    'SP_VISEME_11', 'SRAORetainAudio', 'ISpeechPhraseElements',
    'SRSInactive', 'DISPID_SpeechLexiconPronunciation',
    'SAFT48kHz16BitMono', 'SECNormalConfidence',
    'DISPID_SRSClsidEngine', 'SPEI_START_SR_STREAM',
    'SPINTERFERENCE_TOOFAST', 'SPCS_DISABLED', 'DISPID_SPPChildren',
    'eLEXTYPE_PRIVATE10', 'SPSModifier', 'DISPID_SPPsItem',
    'SPEI_SR_PRIVATE', 'SAFTCCITT_ALaw_11kHzMono',
    'SpeechCategoryAudioIn', 'DISPID_SRCState', 'DISPID_SGRSRule',
    'SGRSTTDictation', 'DISPID_SRCEInterference',
    'DISPID_SRCERequestUI', 'SPDKL_LocalMachine',
    'DISPID_SPEDisplayText', 'DISPID_SRGDictationSetState',
    'DISPID_SPEAudioTimeOffset', 'SPEI_TTS_AUDIO_LEVEL', 'DISPIDSPRG',
    'SpPhoneConverter', 'DISPID_SPAs_NewEnum', 'eLEXTYPE_RESERVED8',
    'SPRECOCONTEXTSTATUS', 'DISPID_SVSyncronousSpeakTimeout',
    'SpeechFormatType', 'ISpXMLRecoResult', 'DISPID_SVSpeakStream',
    'SpeechPropertyResponseSpeed', 'SP_VISEME_10', 'SGRSTTWord',
    'SRTStandard', 'SPCATEGORYTYPE', 'DISPID_SGRClear',
    'SAFTCCITT_ALaw_44kHzMono', 'SPFM_OPEN_READWRITE',
    'SpeechVoiceCategoryTTSRate', 'SRADefaultToActive',
    'ISpNotifySource', 'DISPID_SPILanguageId', 'STSF_FlagCreate',
    'DISPID_SGRAddResource', 'SITooQuiet', 'SPGS_DISABLED',
    'ISpObjectToken', 'DISPID_SGRSAddWordTransition',
    'DISPID_SPAsCount', 'DISPID_SLWLangId',
    'DISPID_SPEAudioSizeBytes', 'eLEXTYPE_PRIVATE5',
    'SVSFPurgeBeforeSpeak', 'DISPID_SLAddPronunciationByPhoneIds',
    'SPFM_NUM_MODES', 'DISPID_SRRDiscardResultInfo',
    'eLEXTYPE_LETTERTOSOUND', 'SpeechAudioProperties',
    'SPCT_SUB_COMMAND', 'SpVoice', 'SAFT8kHz8BitStereo',
    'DISPID_SGRSTPropertyValue', 'SP_VISEME_17', 'SAFT44kHz8BitMono',
    'SECFIgnoreKanaType', 'STSF_AppData', 'SVP_11',
    'SpCompressedLexicon', 'eLEXTYPE_PRIVATE11', 'SGSExclusive',
    'SpeechPropertyLowConfidenceThreshold',
    'DISPID_SpeechRecoContextEvents', 'eLEXTYPE_PRIVATE1',
    'SPEI_SOUND_END', 'SAFTCCITT_uLaw_11kHzMono', 'DISPID_SRRTimes',
    'DISPID_SpeechCustomStream', 'SITooFast',
    'DISPID_SpeechObjectToken', 'SPEI_HYPOTHESIS',
    'SAFTGSM610_44kHzMono',
    'DISPID_SpeechGrammarRuleStateTransitions',
    'DISPID_SRCCreateGrammar', 'SAFTCCITT_ALaw_22kHzMono',
    'SAFT32kHz16BitMono', 'SpeechPartOfSpeech',
    'SPXRO_Alternates_SML', '_ISpeechVoiceEvents', 'SPEI_PHONEME',
    'DISPID_SpeechGrammarRule', 'LONG_PTR', 'SPWT_LEXICAL',
    'SP_VISEME_6', 'eLEXTYPE_PRIVATE17', 'SPPS_Unknown', 'STCAll',
    'SPFM_CREATE', 'SPPS_LMA', 'SP_VISEME_8', 'DISPID_SPRText',
    'SPAUDIOSTATE', 'eLEXTYPE_PRIVATE12', 'DISPID_SPRuleName',
    'SDTAll', 'SRSInactiveWithPurge', 'ISpRecoGrammar',
    'STCLocalServer', 'ISpProperties', 'DISPID_SPELexicalForm',
    'DISPID_SWFEBitsPerSample', 'SpSharedRecoContext',
    'DISPID_SGRsFindRule', 'DISPID_SRCERecognizerStateChange',
    'ISpeechLexiconPronunciations', 'ISpeechLexiconWords',
    'DISPID_SGRSTPropertyName', 'SPCT_COMMAND', 'SGSDisabled',
    'SRAInterpreter', 'SRTExtendableParse', 'eLEXTYPE_APP',
    'DISPID_SOTRemoveStorageFileName', 'DISPID_SPEDisplayAttributes',
    'eLEXTYPE_PRIVATE3', 'SPEI_UNDEFINED', 'SGDSInactive',
    'DISPID_SpeechPhraseRule', 'SpeechCategoryRecognizers',
    'SpeechPropertyComplexResponseSpeed', 'SAFTCCITT_uLaw_8kHzMono',
    'DISPID_SRSSupportedLanguages', 'SPCT_DICTATION', 'SPSLMA',
    'DISPID_SPEsCount', 'SREAllEvents', 'SRSEIsSpeaking',
    'SpeechBookmarkOptions', 'DISPID_SpeechLexicon',
    'DISPID_SASCurrentSeekPosition', 'SPWF_INPUT',
    'DISPID_SPIGetText', 'SPEI_END_INPUT_STREAM', 'DISPID_SVSkip',
    'SAFTNonStandardFormat', 'DISPID_SMSSetData',
    'DISPID_SPAStartElementInResult', 'SpeechTokenKeyFiles',
    'SPWORDPRONUNCIATION', 'DISPID_SVWaitUntilDone',
    'DISPID_SVDisplayUI', 'DISPID_SRRAlternates',
    'DISPID_SPIProperties', 'SP_VISEME_9', 'DISPID_SRCERecognition',
    'SVP_8', 'DISPID_SPIGrammarId', 'SPPHRASEREPLACEMENT',
    'DISPID_SPRs_NewEnum', 'DISPID_SRCSetAdaptationData',
    'DISPID_SRAllowVoiceFormatMatchingOnNextSet', 'SREHypothesis',
    'ISpeechRecoResultTimes', 'DISPID_SRGDictationLoad',
    'SAFTADPCM_22kHzMono', 'DISPID_SpeechPhoneConverter',
    'SPRECORESULTTIMES', 'Speech_StreamPos_RealTime', 'SLTUser',
    'DISPID_SPRulesItem', 'SPTEXTSELECTIONINFO',
    'SpeechGrammarTagWildcard', 'DISPID_SRGCmdLoadFromFile',
    'SPEI_VOICE_CHANGE', 'DISPID_SVPriority',
    'SpTextSelectionInformation', 'SPGRAMMARWORDTYPE', 'SAFTText',
    'SGRSTTRule', 'SPEVENT', 'DISPID_SDKDeleteKey',
    'DISPID_SABufferNotifySize', 'DISPID_SPRNumberOfElements',
    'DISPID_SVEPhoneme', 'SpeechAudioFormatGUIDWave',
    'SPEI_TTS_BOOKMARK', 'DISPID_SRProfile', 'DISPID_SPRFirstElement',
    'eLEXTYPE_PRIVATE6', 'DISPID_SPEActualConfidence',
    'DISPID_SpeechVoiceEvent', 'ISpeechPhraseInfo', 'SECFDefault',
    'ISpeechRecoContext', 'DISPID_SVResume', 'SVPOver', 'SVEPhoneme',
    'DISPID_SRCResume', 'SPAUDIOOPTIONS', 'SpeechVisemeType',
    'eLEXTYPE_RESERVED10', 'SAFTCCITT_uLaw_44kHzMono',
    'DISPID_SVAudioOutputStream', 'SpMMAudioEnum', 'SFTSREngine',
    'DISPID_SPPId', 'SECLowConfidence', 'SPAO_NONE', 'SpFileStream',
    'SPRST_NUM_STATES', 'SREFalseRecognition',
    'ISpPhoneticAlphabetConverter', 'ISpeechGrammarRules',
    'SREAudioLevel', 'ISpeechObjectTokenCategory',
    'SVEEndInputStream', 'SVSFParseSsml', 'ISpeechMemoryStream',
    'DISPID_SAFGuid', 'DISPID_SPEAudioStreamOffset',
    'DISPID_SpeechObjectTokenCategory', 'SpeechEngineConfidence',
    'DISPID_SPCLangId', 'SpeechTokenContext', 'SPAO_RETAIN_AUDIO',
    'DISPID_SPIGetDisplayAttributes', 'eLEXTYPE_MORPHOLOGY',
    'SpeechTokenIdUserLexicon', 'DISPID_SDKEnumKeys',
    'ISpeechRecoGrammar', 'DISPID_SLPPartOfSpeech', 'SGLexical',
    'ISpeechRecognizerStatus', 'SPAS_CLOSED', 'SPPS_Noncontent',
    'ISpObjectTokenCategory', 'SpeechAllElements',
    'DISPID_SLRemovePronunciation', 'DISPID_SVEStreamEnd',
    'DISPID_SRCEBookmark', 'SP_VISEME_15', 'ISpeechGrammarRuleState',
    'DISPID_SABIMinNotification', 'DISPID_SRGetFormat', 'SLODynamic',
    'DISPID_SpeechWaveFormatEx', 'DISPID_SVEEnginePrivate',
    'SPAS_PAUSE', 'SAFT22kHz16BitStereo', 'SVP_2', 'SVP_3',
    'STCInprocServer', 'SAFT22kHz8BitMono', 'ISpRecognizer',
    'SBOPause', 'SpeechGrammarTagDictation',
    'DISPID_SDKGetStringValue', 'SPBO_TIME_UNITS',
    'SpeechCategoryAudioOut', 'SpeechRunState',
    'DISPID_SOTGetAttribute', 'DISPID_SRSetPropertyNumber',
    'DISPID_SGRsAdd', 'DISPIDSPTSI_SelectionLength', 'SP_VISEME_14',
    'DISPID_SRGState', 'SAFT22kHz16BitMono', 'SpShortcut',
    'SPRS_INACTIVE', 'DISPID_SpeechRecoResultTimes', 'SASPause',
    'DISPID_SGRSAddSpecialTransition', 'DISPID_SVSPhonemeId',
    'SRERecognition', 'SpObjectToken', 'Speech_Max_Word_Length',
    'SAFTADPCM_8kHzStereo', 'SpInprocRecognizer', 'SITooLoud',
    'SPAUDIOBUFFERINFO', 'DISPID_SRGSetWordSequenceData',
    'DISPID_SPRuleId', 'SpeechWordType', 'SPSMF_SRGS_SAPIPROPERTIES',
    'ISpeechPhraseProperties', 'DISPID_SPRuleFirstElement',
    'SPWORDPRONUNCIATIONLIST', 'ISpeechGrammarRuleStateTransitions',
    'DISPID_SGRSTsItem', 'DISPID_SLPsItem', 'DISPID_SLPType',
    'SpeechPropertyResourceUsage', 'SPWF_SRENGINE',
    'ISpeechPhraseElement', 'SPAS_RUN', 'SRAONone', 'SPSNoun',
    'SPSMF_SAPI_PROPERTIES', 'SpeechSpecialTransitionType',
    'SSTTWildcard', 'SpeechStreamFileMode', 'SPPS_Modifier',
    '__MIDL___MIDL_itf_sapi_0000_0020_0001', 'SPEI_RESERVED1',
    'SAFTGSM610_22kHzMono', 'DISPID_SOTDataKey',
    'DISPID_SPRuleEngineConfidence', 'ISpeechResourceLoader',
    'DISPID_SpeechFileStream', 'SVSFUnusedFlags',
    'DISPID_SOTs_NewEnum', 'ISpeechObjectTokens',
    'DISPID_SREmulateRecognition', 'DISPID_SLWWord',
    'DISPID_SRAllowAudioInputFormatChangesOnNextSet', 'SRADynamic',
    'SP_VISEME_4', 'SPEI_INTERFERENCE', 'SpStream',
    'SGDSActiveWithAutoPause', 'DISPID_SPRulesCount', 'SVEPrivate',
    'SpeechCategoryAppLexicons', 'SPVPRI_NORMAL', 'SPBO_AHEAD',
    'STSF_LocalAppData', 'SPDKL_CurrentConfig', 'DISPID_SOTCategory',
    'DISPID_SABIEventBias', 'ISpeechWaveFormatEx',
    'DISPID_SLWPronunciations', 'DISPID_SOTsCount',
    'SpeechTokenShellFolder', 'tagSTATSTG', 'DISPID_SRStatus',
    'DISPID_SVGetAudioInputs', 'SpMemoryStream',
    'SAFT11kHz8BitStereo', 'DISPID_SpeechPhraseAlternate',
    'DISPID_SRGSetTextSelection', 'SPSInterjection',
    'DISPID_SpeechRecoResult', 'DISPID_SPEsItem',
    'SpSharedRecognizer', 'SSSPTRelativeToCurrentPosition',
    'ISpeechAudioFormat', 'SAFT11kHz16BitStereo',
    'SpeechRegistryLocalMachineRoot', 'SpeechRecoEvents', 'SPBO_NONE',
    'SAFTCCITT_ALaw_8kHzMono', 'SREBookmark',
    'DISPID_SRGCmdLoadFromProprietaryGrammar', '_SPAUDIOSTATE',
    'DISPID_SVSInputSentencePosition', 'SVP_16', 'SpeechLexiconType',
    'DISPID_SAStatus', 'SPSFunction', 'SRTReSent',
    'DISPID_SPRuleNumberOfElements', 'DISPID_SRIsUISupported',
    'ISpDataKey', 'DISPID_SpeechLexiconWord',
    'SPRS_ACTIVE_WITH_AUTO_PAUSE', 'SPEI_SR_RETAINEDAUDIO',
    'DISPID_SRSetPropertyString', 'SpWaveFormatEx',
    '_RemotableHandle', 'DISPID_SPPName', 'SpeechDiscardType',
    'SpInProcRecoContext', 'DISPID_SOTGetDescription',
    'DISPID_SPPBRestorePhraseFromMemory',
    'DISPID_SPRDisplayAttributes', 'DISPID_SpeechRecoResult2',
    'DISPID_SRCEHypothesis', 'SPSSuppressWord', 'DISPID_SRCVoice',
    'SpMMAudioOut', 'SAFT24kHz16BitMono', 'eLEXTYPE_PRIVATE19',
    'SVP_0', 'SINoise', 'eLEXTYPE_USER_SHORTCUT',
    'DISPID_SRCRetainedAudio', 'SPCT_SUB_DICTATION',
    'SPINTERFERENCE_NONE', 'SPSVerb', 'DISPID_SDKGetBinaryValue',
    'DISPID_SOTId', 'eLEXTYPE_VENDORLEXICON', 'DISPID_SGRSTType',
    'Speech_Default_Weight', 'SP_VISEME_5', 'SAFTADPCM_44kHzStereo',
    'DISPID_SGRSTText', 'DISPID_SDKEnumValues',
    'SpeechEmulationCompareFlags', 'SpeechAddRemoveWord',
    'DISPID_SFSClose', 'DISPID_SpeechLexiconWords', 'SPFILEMODE',
    'DISPID_SPPNumberOfElements', 'DISPID_SPPFirstElement',
    'SVSFIsXML', 'ISpStreamFormatConverter', 'SP_VISEME_1',
    'DISPID_SVSLastResult', 'SAFT22kHz8BitStereo', 'SPXRO_SML',
    'ISpeechLexicon', 'ISpeechVoice', 'SRATopLevel',
    'DISPID_SDKOpenKey', 'SDKLCurrentUser', 'SRTEmulated',
    'SpeechAudioFormatType', 'DISPID_SDKGetlongValue',
    'DISPID_SGRSTsCount', 'DISPID_SAEventHandle',
    '_ISpeechRecoContextEvents', 'DISPID_SVEVoiceChange',
    'SpAudioFormat', 'DISPID_SRCBookmark',
    'DISPID_SVAllowAudioOuputFormatChangesOnNextSet',
    'DISPID_SOTsItem', 'ISpeechAudioStatus',
    'DISPID_SGRsCommitAndSave', 'SPWP_UNKNOWN_WORD_UNPRONOUNCEABLE',
    'SpeechAudioFormatGUIDText', 'DISPID_SPEs_NewEnum', 'SDTAudio',
    'DISPID_SRCVoicePurgeEvent', 'DISPID_SRRRecoContext',
    'DISPID_SGRName', 'SPEI_ADAPTATION',
    'SpeechGrammarTagUnlimitedDictation', 'SPEI_RESERVED2',
    'SAFT11kHz8BitMono', 'DISPID_SRRAudioFormat', 'DISPID_SVEViseme',
    'SVP_18', 'SAFT16kHz8BitStereo', 'DISPID_SGRsDynamic',
    'SDA_Two_Trailing_Spaces', 'DISPID_SOTGetStorageFileName',
    'DISPID_SOTRemove', 'SAFT12kHz16BitStereo', 'SPXMLRESULTOPTIONS',
    'DISPID_SOTSetId', 'SPSHT_OTHER', 'DISPID_SPEEngineConfidence',
    'SAFTTrueSpeech_8kHz1BitMono', 'SVP_1', 'SREPhraseStart',
    'SSSPTRelativeToStart', 'SVPNormal', 'ISpeechPhraseInfoBuilder',
    'SAFT8kHz8BitMono', 'SpeechAudioVolume', 'SAFT16kHz16BitStereo',
    'SPVPRIORITY', 'DISPID_SGRAddState', 'DISPID_SRAudioInputStream',
    'SDTProperty', 'SAFT32kHz8BitMono', 'DISPID_SpeechObjectTokens',
    'DISPID_SVSInputSentenceLength', 'DISPID_SBSRead',
    'ISpeechPhraseReplacement', 'DISPID_SOTCDefault',
    'eLEXTYPE_PRIVATE4', 'SGDSActive', 'DISPID_SVEAudioLevel',
    'DISPID_SRIsShared', 'DISPID_SLGetPronunciations',
    'DISPID_SGRsCount', 'ISpeechXMLRecoResult', 'ISpeechFileStream',
    'SpeechRecognizerState', 'tagSPPROPERTYINFO',
    'DISPID_SRRecognizer', 'SAFT12kHz8BitStereo',
    'DISPID_SRCESoundEnd', 'DISPID_SpeechPhraseReplacements',
    'eLEXTYPE_PRIVATE13', 'SAFT48kHz16BitStereo', 'DISPID_SMSGetData',
    'eLEXTYPE_PRIVATE7', 'DISPID_SpeechRecoContext',
    'DISPID_SAFGetWaveFormatEx', 'SINone',
    'SWPUnknownWordPronounceable', 'ISpMMSysAudio', 'ISpPhraseAlt',
    'DISPID_SRCEFalseRecognition', 'DISPID_SVEventInterests',
    'SpCustomStream', 'SPAR_Unknown', 'SPVPRI_ALERT',
    'DISPID_SOTIsUISupported', 'eLEXTYPE_RESERVED4', 'SSTTTextBuffer',
    'eLEXTYPE_RESERVED6', 'SPWP_KNOWN_WORD_PRONOUNCEABLE',
    'SPINTERFERENCE_NOSIGNAL', 'ISpNotifySink',
    'DISPID_SpeechVoiceStatus', 'SSFMOpenForRead', 'SPINTERFERENCE',
    'SPEI_RESERVED6', 'SAFTDefault', 'SAFT24kHz16BitStereo',
    'DISPID_SRGCmdLoadFromResource', 'DISPID_SPRuleConfidence',
    'DISPID_SVAudioOutput', 'DISPID_SRGRules', 'SPEI_SR_AUDIO_LEVEL',
    'DISPIDSPTSI_ActiveOffset', 'DISPID_SpeechAudioBufferInfo',
    'DISPID_SLPs_NewEnum', 'DISPID_SVSInputWordPosition', 'SVP_6',
    'DISPID_SRGIsPronounceable', 'ISpeechGrammarRuleStateTransition',
    'SPEI_SENTENCE_BOUNDARY', 'SAFT44kHz16BitMono',
    'DISPID_SGRSTs_NewEnum', 'SPAUDIOSTATUS', 'SVSFPersistXML',
    'DISPID_SDKDeleteValue', 'DISPID_SASFreeBufferSpace',
    'DISPID_SpeechRecognizer', 'IStream', 'SVEWordBoundary',
    'SPEI_MAX_SR', 'ISpeechAudio', 'DISPID_SRRGetXMLResult',
    'SVF_None', 'DISPID_SPAsItem',
    'DISPID_SRCAudioInInterferenceStatus', 'DISPID_SVSVisemeId',
    'SpeechVisemeFeature', 'ISpeechPhraseRule', 'eLEXTYPE_PRIVATE9',
    'SREStateChange', 'DISPID_SPRuleChildren',
    'SPSMF_SRGS_SEMANTICINTERPRETATION_W3C', 'SPPS_SuppressWord',
    'DISPID_SLPSymbolic', 'SPRST_ACTIVE_ALWAYS',
    'DISPID_SRCRecognizer', 'SpeechCategoryPhoneConverters',
    'SPINTERFERENCE_TOOSLOW', 'DISPID_SGRSTransitions', 'SPEI_VISEME',
    'DISPID_SpeechPhraseReplacement', 'SAFT16kHz8BitMono',
    'ISpRecoResult', 'SPINTERFERENCE_TOOLOUD',
    'ISpeechRecoResultDispatch', 'eLEXTYPE_USER', 'SP_VISEME_13',
    'SpeechRuleState', 'SpeechUserTraining', 'SAFT32kHz8BitStereo',
    'SECFNoSpecialChars', 'SAFTADPCM_44kHzMono', 'DISPID_SRState',
    'eLEXTYPE_PRIVATE16', 'SSFMCreate', 'eLEXTYPE_PRIVATE20',
    'SVSFNLPSpeakPunc', 'SPEI_SOUND_START',
    'DISPID_SVSpeakCompleteEvent', 'DISPID_SPAPhraseInfo',
    'DISPID_SWFEBlockAlign', 'SGRSTTTextBuffer', 'SREStreamEnd',
    'SAFT8kHz16BitStereo', 'STSF_CommonAppData',
    'DISPID_SRSAudioStatus', 'DISPID_SPANumberOfElementsInResult',
    'SPEI_RESERVED5', 'ISpeechMMSysAudio',
    'SPSMF_SRGS_SEMANTICINTERPRETATION_MS',
    'SpeechRecoProfileProperties', 'SP_VISEME_0',
    'DISPID_SRGetRecognizers', 'DISPID_SPERetainedStreamOffset',
    'DISPID_SRCEEnginePrivate', 'SAFT12kHz16BitMono',
    'DISPID_SRRTLength', 'SPSNotOverriden', 'SRAExport',
    'ISpeechObjectToken', 'SPWORDLIST', 'DISPID_SpeechAudioFormat',
    'SAFTADPCM_8kHzMono', 'DISPID_SOTDisplayUI',
    'SPEI_FALSE_RECOGNITION', 'SPRST_INACTIVE', 'SPSHT_EMAIL',
    'SPEI_MAX_TTS', 'ISpShortcut', 'SP_VISEME_21',
    'DISPID_SpeechPhraseInfo', 'SPAR_Low',
    'DISPID_SLAddPronunciation', 'ISpSerializeState',
    'SpNotifyTranslator', 'ISpeechCustomStream', 'ISpLexicon',
    'SAFTADPCM_22kHzStereo', 'DISPID_SGRSTWeight',
    'DISPID_SpeechMemoryStream', 'SPSHORTCUTTYPE', 'SRERequestUI',
    'SRSActiveAlways', 'SP_VISEME_12', 'DISPID_SLWs_NewEnum',
    'SpeechDisplayAttributes', 'DISPID_SVEWord',
    'SAFTCCITT_uLaw_22kHzMono', 'DISPID_SRGCommit',
    'SPADAPTATIONRELEVANCE', 'SPPS_Noun', 'IInternetSecurityMgrSite',
    'SpeechVoiceSpeakFlags', 'DISPID_SPPValue', 'WAVEFORMATEX',
    'DISPID_SGRSTNextState', 'DISPID_SPACommit',
    'SAFT44kHz16BitStereo', 'SAFT8kHz16BitMono',
    'DISPID_SRSNumberOfActiveRules', 'SPLO_DYNAMIC', 'SPPHRASE',
    'DISPID_SPIAudioSizeBytes', 'SPWORDTYPE', 'SDTReplacement',
    'SP_VISEME_3', 'DISPID_SPARecoResult', 'ISpRecoContext2',
    'ISpeechAudioBufferInfo', 'DISPID_SPIAudioStreamPosition',
    'SPEI_END_SR_STREAM', 'SpeechStreamSeekPositionType', 'SPAS_STOP',
    'DISPID_SpeechPhraseAlternates', 'ISpNotifyTranslator',
    'ISpeechGrammarRule', 'DISPID_SAFSetWaveFormatEx',
    'SPEI_RECOGNITION', 'DISPID_SABufferInfo', 'DISPID_SGRs_NewEnum',
    'SVSFlagsAsync', 'DISPID_SVESentenceBoundary',
    'DISPID_SRGCmdLoadFromObject', 'SPPS_Interjection',
    'eLEXTYPE_PRIVATE14', 'SVEStartInputStream', 'eLEXTYPE_PRIVATE8',
    'DISPID_SLPLangId', 'SpMMAudioIn', 'DISPIDSPTSI',
    'SGLexicalNoSpecialChars', 'SAFTCCITT_ALaw_11kHzStereo',
    'SASClosed', 'SRTSMLTimeout', 'SFTInput', 'SRESoundEnd',
    'DISPID_SRGCmdLoadFromMemory', 'DISPID_SDKSetLongValue',
    'SVF_Emphasis', 'ISpEventSource', 'SAFTCCITT_uLaw_11kHzStereo',
    'ISpeechPhraseProperty', 'DISPID_SPIEnginePrivateData',
    'DISPID_SPPParent', 'DISPID_SPIRule', 'SPCT_SLEEP',
    'SPEVENTSOURCEINFO', 'DISPID_SPPEngineConfidence',
    'DISPID_SRRSetTextFeedback', 'DISPID_SOTCId',
    'SAFTCCITT_uLaw_8kHzStereo', 'SLOStatic', 'SPSERIALIZEDRESULT',
    'DISPID_SDKCreateKey', 'DISPID_SRGReset', 'SGRSTTWildcard',
    'SGDSActiveUserDelimited', 'SVEBookmark',
    'SDA_One_Trailing_Space', 'SPINTERFERENCE_NOISE',
    'DISPID_SRRTStreamTime', 'DISPID_SpeechPhraseElements',
    'SpeechLoadOption', 'DISPID_SRDisplayUI',
    'DISPID_SASCurrentDevicePosition', 'SPSHORTCUTPAIR',
    'SDA_No_Trailing_Space', 'DISPID_SGRsItem',
    'DISPID_SVSLastBookmarkId', 'DISPID_SOTCSetId',
    'SPEI_WORD_BOUNDARY', 'DISPID_SMSADeviceId', 'SPPHRASEELEMENT',
    'SpeechTokenValueCLSID', 'SpObjectTokenCategory',
    'DISPID_SVGetProfiles', 'SpResourceManager',
    'SpeechEngineProperties', 'SpeechCategoryRecoProfiles',
    'ISpeechTextSelectionInformation', 'SP_VISEME_19',
    'DISPID_SPRules_NewEnum', 'SVSFVoiceMask', 'ISpeechRecoResult',
    'DISPID_SBSFormat', 'DISPID_SPCPhoneToId', 'SP_VISEME_2',
    'ISpRecognizer3', 'ISpeechLexiconWord', 'eWORDTYPE_ADDED',
    'DISPID_SGRsCommit', 'DISPID_SVSLastBookmark', 'SPSUnknown',
    'SREPropertyStringChange', 'DISPID_SLWType',
    'SAFTCCITT_ALaw_22kHzStereo', 'DISPID_SVPause', 'SPPHRASERULE',
    'SPPS_Function', 'SPEVENTENUM', 'DISPID_SpeechPhraseProperties',
    'ISpRecoGrammar2'
]

